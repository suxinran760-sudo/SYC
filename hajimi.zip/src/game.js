import * as THREE from 'three';
import { WEAPONS, buildWeaponModel } from './weapons.js';
import { buildMap } from './map.js';
import { sfx, initAudio } from './audio.js';

const $ = (id) => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;

const QUALITY = {
  low:    { pr: 0.55, cap: 1.0, shadow: 0,    flash: false, aa: false },
  medium: { pr: 0.75, cap: 1.5, shadow: 1024, flash: true,  aa: false },
  high:   { pr: 1.0,  cap: 2.0, shadow: 2048, flash: true,  aa: true },
  ultra:  { pr: 1.0,  cap: 2.5, shadow: 3072, flash: true,  aa: true }
};
const TOD = {
  day:   { top: 0x3f7fd0, horizon: 0xbcd6ee, sun: 0xfff1d6, sunI: 2.8, hemiS: 0x9ec7ff, hemiG: 0x4a4636, hemiI: 1.0, fog: 0xbcd6ee, near: 50, far: 170, dir: [-0.5, 0.8, 0.35], cloud: 0.6, exp: 1.0 },
  dusk:  { top: 0x3b3f78, horizon: 0xf2a15c, sun: 0xff9a55, sunI: 1.9, hemiS: 0x8a7aa8, hemiG: 0x3a2f2a, hemiI: 0.7, fog: 0xd9945f, near: 35, far: 150, dir: [-0.9, 0.25, 0.3], cloud: 0.7, exp: 1.0 },
  night: { top: 0x04060e, horizon: 0x16213a, sun: 0x8fa8ff, sunI: 0.45, hemiS: 0x2a3a66, hemiG: 0x101018, hemiI: 0.55, fog: 0x0b1020, near: 18, far: 110, dir: [0.3, 0.6, -0.5], cloud: 0.2, exp: 1.25 }
};

const EYE_STAND = 1.6, EYE_CROUCH = 1.05, H_STAND = 1.75, H_CROUCH = 1.2, RADIUS = 0.4, STEP = 0.45, GRAV = 18, JUMP = 6.0;

function skyMaterial() {
  return new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: {
      top: { value: new THREE.Color() }, horizon: { value: new THREE.Color() }, sunCol: { value: new THREE.Color() },
      sunDir: { value: new THREE.Vector3(0, 1, 0) }, time: { value: 0 }, cloud: { value: 0.6 }
    },
    vertexShader: 'varying vec3 vDir; void main(){ vDir=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }',
    fragmentShader: `
      varying vec3 vDir; uniform vec3 top,horizon,sunCol,sunDir; uniform float time,cloud;
      float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}
      void main(){
        vec3 d=normalize(vDir); float y=clamp(d.y,0.,1.);
        vec3 col=mix(horizon,top,pow(y,.55));
        float sd=max(dot(d,normalize(sunDir)),0.);
        col+=sunCol*(pow(sd,700.)*2.5+pow(sd,10.)*.22);
        if(d.y>0.02){
          vec2 uv=d.xz/(d.y+.2)*1.4+time*.012;
          float c=n(uv*2.)*.5+n(uv*4.)*.25+n(uv*8.)*.125;
          c=smoothstep(.5+(1.-cloud)*.25,.95,c);
          col=mix(col,mix(horizon,vec3(1.),.7)*.9,c*.75*smoothstep(0.,.25,d.y));
        }
        gl_FragColor=vec4(col,1.);
        #include <colorspace_fragment>
      }`
  });
}

function makeHoleTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d');
  const g = x.createRadialGradient(32, 32, 2, 32, 32, 30);
  g.addColorStop(0, 'rgba(0,0,0,0.95)'); g.addColorStop(0.35, 'rgba(15,15,15,0.8)'); g.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = g; x.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}
function makeFlashTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d');
  const g = x.createRadialGradient(32, 32, 1, 32, 32, 30);
  g.addColorStop(0, 'rgba(255,255,230,1)'); g.addColorStop(0.3, 'rgba(255,200,90,0.8)'); g.addColorStop(1, 'rgba(255,120,0,0)');
  x.fillStyle = g; x.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

export class Game {
  constructor(canvas, settings) {
    this.canvas = canvas; this.S = settings;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, 1, 0.05, 700);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    this.sky = new THREE.Mesh(new THREE.SphereGeometry(500, 24, 16), skyMaterial());
    this.sky.renderOrder = -10; this.scene.add(this.sky);
    this.hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1); this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xffffff, 2.5);
    this.sun.shadow.camera.left = -62; this.sun.shadow.camera.right = 62; this.sun.shadow.camera.top = 62; this.sun.shadow.camera.bottom = -62;
    this.sun.shadow.camera.near = 1; this.sun.shadow.camera.far = 200; this.sun.shadow.bias = -0.0006; this.sun.shadow.normalBias = 0.04;
    this.scene.add(this.sun); this.scene.add(this.sun.target);
    this.flashLight = new THREE.PointLight(0xffc070, 0, 9, 2); this.scene.add(this.flashLight);

    this.vm = new THREE.Group(); this.camera.add(this.vm);
    this.modelCache = {};

    this.raycaster = new THREE.Raycaster();
    this.inp = { mx: 0, my: 0, lookX: 0, lookY: 0, gyroYaw: 0, gyroPitch: 0, fire: false, jump: false, reload: false, sw: false, grenade: false, adsTap: false, crouchTap: false, zoomTap: false };

    this.holeTex = makeHoleTexture(); this.flashTex = makeFlashTexture();
    this.initPools();
    this.world = null; this.worldTod = null; this.root = null;
    this.running = false; this.paused = false; this.lastT = 0; this.frames = 0; this.fpsT = 0;
    this.motionHandler = this.onMotion.bind(this);
    this.lastMotion = 0;
    window.addEventListener('resize', () => this.resize());
    this.applySettings();
    this.resize();
    this.renderer.setAnimationLoop(this.loop.bind(this));
  }

  initPools() {
    this.decals = []; this.decalIdx = 0;
    const dm = new THREE.MeshBasicMaterial({ map: this.holeTex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4 });
    this.decalGeo = new THREE.PlaneGeometry(0.14, 0.14); this.decalMat = dm;
    this.parts = [];
    const pm = new THREE.MeshBasicMaterial({ color: 0xffc766 });
    const pg = new THREE.SphereGeometry(0.035, 5, 4);
    for (let i = 0; i < 48; i++) { const m = new THREE.Mesh(pg, pm); m.visible = false; this.scene.add(m); this.parts.push({ m, v: new THREE.Vector3(), life: 0 }); }
    this.tracers = [];
    const tm = new THREE.MeshBasicMaterial({ color: 0xffd890, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
    const tg = new THREE.BoxGeometry(1, 1, 1);
    for (let i = 0; i < 16; i++) { const m = new THREE.Mesh(tg, tm); m.visible = false; this.scene.add(m); this.tracers.push({ m, life: 0 }); }
    this.tracerIdx = 0; this.partIdx = 0;
    const fm = new THREE.MeshBasicMaterial({ map: this.flashTex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    this.flashMesh = new THREE.Group();
    const f1 = new THREE.Mesh(new THREE.PlaneGeometry(0.28, 0.28), fm);
    const f2 = f1.clone(); f2.rotation.z = Math.PI / 2; const f3 = f1.clone(); f3.rotation.y = Math.PI / 2;
    this.flashMesh.add(f1, f2, f3); this.flashMesh.visible = false;
    this.boom = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 10), new THREE.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending, depthWrite: false }));
    this.boom.visible = false; this.scene.add(this.boom); this.boomT = 0; this.boomPos = new THREE.Vector3();
  }

  // ---------- 设置 ----------
  applySettings() {
    const q = QUALITY[this.S.quality] || QUALITY.medium;
    this.q = q;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio * q.pr, q.cap));
    const wasShadow = this.renderer.shadowMap.enabled;
    this.renderer.shadowMap.enabled = q.shadow > 0;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.sun.castShadow = q.shadow > 0;
    if (q.shadow > 0 && this.sun.shadow.mapSize.x !== q.shadow) {
      this.sun.shadow.mapSize.set(q.shadow, q.shadow);
      if (this.sun.shadow.map) { this.sun.shadow.map.dispose(); this.sun.shadow.map = null; }
    }
    if (wasShadow !== this.renderer.shadowMap.enabled) this.scene.traverse(o => { if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => m.needsUpdate = true); } });
    this.resize();
    $('fpsBox').style.display = this.S.showFps ? 'block' : 'none';
    this.camera.fov = this.S.fov; this.camera.updateProjectionMatrix();
  }
  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
  }
  applyTod(name) {
    const t = TOD[name] || TOD.day;
    const u = this.sky.material.uniforms;
    u.top.value.set(t.top); u.horizon.value.set(t.horizon); u.sunCol.value.set(t.sun); u.cloud.value = t.cloud;
    u.sunDir.value.set(...t.dir);
    this.sun.color.set(t.sun); this.sun.intensity = t.sunI;
    this.sun.position.set(t.dir[0] * 70, t.dir[1] * 70, t.dir[2] * 70);
    this.hemi.color.set(t.hemiS); this.hemi.groundColor.set(t.hemiG); this.hemi.intensity = t.hemiI;
    this.scene.fog = new THREE.Fog(t.fog, t.near, t.far);
    this.renderer.toneMappingExposure = t.exp;
  }

  // ---------- 开始 / 结束 ----------
  start(cfg) {
    initAudio();
    this.cfg = cfg;
    if (!this.world || this.worldTod !== cfg.tod) {
      if (this.root) { this.scene.remove(this.root); this.root.traverse(o => { if (o.geometry) o.geometry.dispose(); }); }
      this.root = new THREE.Group(); this.scene.add(this.root);
      this.world = buildMap(this.root, cfg.tod); this.worldTod = cfg.tod;
    }
    this.applyTod(cfg.tod);
    // 玩家
    const sp = this.world.spawns[(Math.random() * this.world.spawns.length) | 0];
    this.p = { x: sp.x, y: 0, z: sp.z, vx: 0, vz: 0, vy: 0, yaw: sp.yaw, pitch: 0, crouch: false, eye: EYE_STAND, ground: true, hp: 100, bob: 0, step: 0, fallV: 0 };
    // 武器
    const mk = (id) => ({ id, mag: WEAPONS[id].mag, reserve: WEAPONS[id].reserve });
    this.slots = [mk(this.S.primary), mk(this.S.secondary)];
    this.cur = 0; this.grenades = 3; this.grenT = 0;
    this.reloading = false; this.reloadT = 0; this.fireCool = 0; this.semiLock = false; this.swapT = 0; this.swapPending = -1;
    this.ads = false; this.adsT = 0; this.zoomIdx = 0; this.startReloadSoon = 0; this.bloom = 0; this.kickZ = 0; this.kickRot = 0; this.flashT = 0; this.shake = 0;
    this.equipModel();
    // 机器人靶
    if (this.bots) this.bots.forEach(b => this.scene.remove(b.group));
    this.bots = [];
    const n = cfg.targets;
    const speed = cfg.mode === 'practice' ? 0 : [1.3, 2.3, 3.4][cfg.diff] || 2.3;
    for (let i = 0; i < n; i++) { const b = this.makeBot(speed); this.bots.push(b); this.respawnBot(b, true); }
    this.grenList = [];
    // 统计
    this.kills = 0; this.heads = 0; this.shots = 0; this.hits = 0;
    this.timeLeft = cfg.mode === 'kill' ? 300 : 0; this.elapsed = 0;
    this.mmDirty = 0;
    this.buildMinimapStatic();
    $('killfeed').innerHTML = '';
    this.updateHud();
    this.attachMotion();
    this.running = true; this.paused = false; this.lastT = performance.now();
  }
  stop() { this.running = false; this.detachMotion(); this.inp.fire = false; this.vm.visible = false; }
  setPaused(v) { this.paused = v; if (!v) this.lastT = performance.now(); }

  attachMotion() { window.addEventListener('devicemotion', this.motionHandler); }
  detachMotion() { window.removeEventListener('devicemotion', this.motionHandler); }
  onMotion(e) {
    if (!this.running || this.paused || this.S.gyro === 'off') return;
    if (this.S.gyro === 'ads' && !this.ads) { this.lastMotion = 0; return; }
    const now = performance.now();
    const dt = this.lastMotion ? Math.min(0.1, (now - this.lastMotion) / 1000) : 0; this.lastMotion = now;
    const rr = e.rotationRate, g = e.accelerationIncludingGravity;
    if (!rr || !g || !dt) return;
    const d2r = Math.PI / 180;
    const wx = (rr.beta || 0) * d2r, wy = (rr.gamma || 0) * d2r, wz = (rr.alpha || 0) * d2r;
    let gx = g.x || 0, gy = g.y || 0, gz = g.z || 0; const gl = Math.hypot(gx, gy, gz) || 1; gx /= gl; gy /= gl; gz /= gl;
    const yawRate = wx * gx + wy * gy + wz * gz;
    const ang = ((screen.orientation && screen.orientation.angle) || window.orientation || 0);
    const a = ((ang % 360) + 360) % 360;
    const R = a === 90 ? [0, -1, 0] : a === 270 ? [0, 1, 0] : a === 180 ? [-1, 0, 0] : [1, 0, 0];
    const pitchRate = wx * R[0] + wy * R[1] + wz * R[2];
    const k = this.S.gyroSens * 1.0;
    this.inp.gyroYaw += yawRate * dt * k;
    this.inp.gyroPitch += pitchRate * dt * k * (this.S.gyroInvert ? -1 : 1);
  }

  // ---------- 机器人 ----------
  makeBot(speed) {
    const g = new THREE.Group();
    const body = new THREE.MeshStandardMaterial({ color: 0x9b2f26, roughness: 0.8 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x2b2f36, roughness: 0.8 });
    const skin = new THREE.MeshStandardMaterial({ color: 0xc89a78, roughness: 0.8 });
    const hit = [];
    const part = (geo, mat, x, y, z, zone) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.userData.zone = zone; m.castShadow = true; g.add(m); hit.push(m); return m; };
    part(new THREE.BoxGeometry(0.5, 0.62, 0.28), body, 0, 1.2, 0, 'body');
    const head = part(new THREE.SphereGeometry(0.14, 12, 10), skin, 0, 1.68, 0, 'head');
    part(new THREE.BoxGeometry(0.16, 0.6, 0.18), body, -0.34, 1.18, 0, 'body');
    part(new THREE.BoxGeometry(0.16, 0.6, 0.18), body, 0.34, 1.18, 0, 'body');
    const legL = part(new THREE.BoxGeometry(0.2, 0.85, 0.22), dark, -0.13, 0.43, 0, 'leg');
    const legR = part(new THREE.BoxGeometry(0.2, 0.85, 0.22), dark, 0.13, 0.43, 0, 'leg');
    const b = { group: g, hit, legL, legR, head, hp: 100, alive: true, deadT: 0, speed, tx: 0, tz: 0, stuck: 0, walkT: Math.random() * 6, respT: 0, x: 0, z: 0, y: 0, yaw: 0 };
    hit.forEach(m => { m.userData.bot = b; });
    this.scene.add(g);
    return b;
  }
  respawnBot(b, first) {
    const pts = this.world.openPoints.concat(this.world.spawns.map(s => [s.x, s.z]));
    let best = null;
    for (let k = 0; k < 8; k++) {
      const pt = pts[(Math.random() * pts.length) | 0];
      const d = Math.hypot(pt[0] - this.p.x, pt[1] - this.p.z);
      if (d > (first ? 8 : 14) && !this.bots.some(o => o !== b && o.alive && Math.hypot(o.x - pt[0], o.z - pt[1]) < 2)) { best = pt; break; }
    }
    if (!best) best = pts[(Math.random() * pts.length) | 0];
    b.x = best[0]; b.z = best[1]; b.y = 0; b.hp = 100; b.alive = true; b.deadT = 0;
    b.group.rotation.set(0, 0, 0); b.group.visible = true;
    this.pickTarget(b);
    b.yaw = Math.atan2(this.p.x - b.x, this.p.z - b.z) + Math.PI;
    b.group.position.set(b.x, 0, b.z); b.group.rotation.y = b.yaw;
    b.group.updateMatrixWorld(true);
  }
  pickTarget(b) {
    const pts = this.world.openPoints;
    const pt = pts[(Math.random() * pts.length) | 0];
    b.tx = pt[0]; b.tz = pt[1]; b.stuck = 0;
  }
  updateBots(dt) {
    for (const b of this.bots) {
      if (!b.alive) {
        b.deadT += dt;
        const f = clamp(b.deadT / 0.35, 0, 1);
        b.group.rotation.x = -f * Math.PI / 2;
        b.group.position.y = f * 0.15;
        b.group.updateMatrixWorld(true);
        if (b.deadT > 2.5) this.respawnBot(b, false);
        continue;
      }
      if (b.speed > 0) {
        let dx = b.tx - b.x, dz = b.tz - b.z; const d = Math.hypot(dx, dz);
        if (d < 1) this.pickTarget(b);
        else {
          dx /= d; dz /= d;
          const pos = { x: b.x, y: 0, z: b.z };
          this.moveHoriz(pos, dx * b.speed * dt, dz * b.speed * dt, 0.35, 1.8);
          const moved = Math.hypot(pos.x - b.x, pos.z - b.z);
          if (moved < b.speed * dt * 0.3) { b.stuck += dt; if (b.stuck > 0.5) this.pickTarget(b); } else b.stuck = 0;
          b.x = pos.x; b.z = pos.z;
          const ty = Math.atan2(dx, dz) + Math.PI;
          let dy = ty - b.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); b.yaw += dy * Math.min(1, dt * 8);
          b.walkT += dt * b.speed * 3;
          b.legL.rotation.x = Math.sin(b.walkT) * 0.6; b.legR.rotation.x = -Math.sin(b.walkT) * 0.6;
        }
      }
      b.group.position.set(b.x, 0, b.z); b.group.rotation.y = b.yaw;
      b.group.updateMatrixWorld(true);
    }
  }

  // ---------- 碰撞 ----------
  moveHoriz(pos, dx, dz, r, h) {
    pos.x += dx; pos.z += dz;
    const cols = this.world.colliders;
    for (let it = 0; it < 3; it++) {
      for (let i = 0; i < cols.length; i++) {
        const c = cols[i];
        if (pos.y + STEP >= c.maxY || pos.y + h <= c.minY) continue;
        if (pos.x < c.minX - r || pos.x > c.maxX + r || pos.z < c.minZ - r || pos.z > c.maxZ + r) continue;
        const cx = clamp(pos.x, c.minX, c.maxX), cz = clamp(pos.z, c.minZ, c.maxZ);
        const ex = pos.x - cx, ez = pos.z - cz, d2 = ex * ex + ez * ez;
        if (d2 < r * r) {
          if (d2 > 1e-8) { const d = Math.sqrt(d2), push = r - d; pos.x += ex / d * push; pos.z += ez / d * push; }
          else {
            const l = pos.x - c.minX, rr = c.maxX - pos.x, t = pos.z - c.minZ, b = c.maxZ - pos.z, m = Math.min(l, rr, t, b);
            if (m === l) pos.x = c.minX - r; else if (m === rr) pos.x = c.maxX + r; else if (m === t) pos.z = c.minZ - r; else pos.z = c.maxZ + r;
          }
        }
      }
    }
    const B = this.world.bounds - 0.8;
    pos.x = clamp(pos.x, -B, B); pos.z = clamp(pos.z, -B, B);
  }
  groundAt(x, y, z, r) {
    let gh = 0; const cols = this.world.colliders;
    for (let i = 0; i < cols.length; i++) {
      const c = cols[i];
      if (c.maxY > y + STEP + 0.001 || c.maxY <= gh) continue;
      const cx = clamp(x, c.minX, c.maxX), cz = clamp(z, c.minZ, c.maxZ);
      const dx = x - cx, dz = z - cz;
      if (dx * dx + dz * dz < r * r) gh = c.maxY;
    }
    return gh;
  }
  canStand() {
    const p = this.p, cols = this.world.colliders;
    for (let i = 0; i < cols.length; i++) {
      const c = cols[i];
      if (c.minY < p.y + H_STAND && c.minY >= p.y + H_CROUCH - 0.05) {
        const cx = clamp(p.x, c.minX, c.maxX), cz = clamp(p.z, c.minZ, c.maxZ);
        const dx = p.x - cx, dz = p.z - cz;
        if (dx * dx + dz * dz < RADIUS * RADIUS) return false;
      }
    }
    return true;
  }

  // ---------- 武器 ----------
  get slot() { return this.slots[this.cur]; }
  get W() { return WEAPONS[this.slot.id]; }
  equipModel() {
    this.vm.clear();
    const id = this.slot.id, skin = this.S.skins[id] || 0;
    const key = id + ':' + skin;
    if (!this.modelCache[key]) this.modelCache[key] = buildWeaponModel(id, skin);
    this.model = this.modelCache[key];
    this.vm.add(this.model);
    this.model.userData.muzzle.add(this.flashMesh);
    this.vm.visible = true;
    $('wName').textContent = this.W.name;
    this.updateAmmo();
  }
  switchWeapon() {
    if (this.swapT > 0) return;
    this.swapPending = 1 - this.cur; this.swapT = 0.42;
    this.reloading = false; this.ads = false; sfx.switchW();
  }
  startReload() {
    const s = this.slot, w = this.W;
    if (this.reloading || s.mag >= w.mag || s.reserve <= 0 || this.swapT > 0) return;
    this.reloading = true; this.reloadT = 0; this.ads = false;
    sfx.reload(w.reload);
  }
  spreadNow() {
    const w = this.W, p = this.p;
    const base = lerp(w.spreadHip, w.spreadAds, this.adsT);
    const sp = Math.hypot(p.vx, p.vz) / 5;
    return (base + sp * 0.014 * (1 - this.adsT * 0.7) + (p.ground ? 0 : 0.03) + this.bloom) * (p.crouch ? 0.7 : 1);
  }
  fire() {
    const s = this.slot, w = this.W;
    this.fireCool = 60 / w.rpm;
    s.mag--; this.shots++;
    this.updateAmmo();
    sfx.shot(w.type);
    const spread = this.spreadNow();
    this.camera.updateMatrixWorld(true);
    const origin = new THREE.Vector3().setFromMatrixPosition(this.camera.matrixWorld);
    const muzzle = new THREE.Vector3(); this.model.userData.muzzle.getWorldPosition(muzzle);
    let anyHit = false, killedHead = false;
    for (let i = 0; i < w.pellets; i++) {
      const r = Math.sqrt(Math.random()) * Math.tan(spread), a = Math.random() * Math.PI * 2;
      const dir = new THREE.Vector3(Math.cos(a) * r, Math.sin(a) * r, -1).normalize().applyQuaternion(this.camera.quaternion);
      const res = this.shootRay(origin, dir, w);
      this.addTracer(muzzle, res.point);
      if (res.botHit) anyHit = true;
    }
    this.bloom = Math.min(0.05, this.bloom + w.recoil * 1.4);
    // 后坐力
    const rec = w.recoil * (this.ads ? 0.7 : 1) * (this.p.crouch ? 0.8 : 1);
    this.p.pitch += rec * (0.8 + Math.random() * 0.4);
    this.p.yaw += (Math.random() - 0.5) * rec * 0.8;
    this.kickZ = Math.min(0.12, this.kickZ + 0.03 + w.recoil * 2); this.kickRot = Math.min(0.25, this.kickRot + 0.03 + w.recoil * 3);
    this.flashT = 0.045; this.shake = Math.max(this.shake, w.recoil * 6);
    if (navigator.vibrate) navigator.vibrate(w.type === 'sniper' || w.type === 'shotgun' ? 25 : 8);
    if (anyHit) this.hits++;
    if (this.slot.mag <= 0) this.startReloadSoon = 0.25;
  }
  shootRay(origin, dir, w) {
    const targets = [];
    for (const b of this.bots) if (b.alive) for (const m of b.hit) targets.push(m);
    const list = this.world.meshes.concat(targets);
    this.raycaster.set(origin, dir); this.raycaster.far = w.range;
    const hits = this.raycaster.intersectObjects(list, false);
    const h = hits[0];
    const out = { point: origin.clone().addScaledVector(dir, w.range), botHit: false };
    if (!h) return out;
    out.point = h.point.clone();
    const bot = h.object.userData.bot;
    if (bot) {
      out.botHit = true;
      const zone = h.object.userData.zone;
      const falloff = clamp(1 - Math.max(0, h.distance - w.range * 0.35) / w.range * 0.7, w.type === 'shotgun' ? 0.2 : 0.55, 1);
      const mul = zone === 'head' ? w.headMul : zone === 'leg' ? 0.75 : 1;
      this.damageBot(bot, w.dmg * mul * falloff, zone === 'head', w.name);
      this.sparks(h.point, new THREE.Vector3(0, 1, 0), 3, 0xff4030);
    } else {
      const n = h.face ? h.face.normal.clone().transformDirection(h.object.matrixWorld) : new THREE.Vector3(0, 1, 0);
      this.addDecal(h.point, n);
      this.sparks(h.point, n, 4, 0xffc766);
      const mt = h.object.material;
      if (mt && mt.metalness > 0.4) sfx.metal(); else sfx.wall();
    }
    return out;
  }
  damageBot(b, dmg, head, wname) {
    if (!b.alive) return;
    b.hp -= dmg;
    const hm = $('hitmark'); hm.className = 'show' + (head ? ' head' : ''); hm.offsetWidth; // 重启动画
    clearTimeout(this.hmT); this.hmT = setTimeout(() => { hm.className = ''; }, 140);
    sfx.hit(head);
    if (b.hp <= 0) {
      b.alive = false; b.deadT = 0; this.kills++; if (head) this.heads++;
      sfx.kill(); this.feed(`你 <b>[${wname}]</b> 击杀了 靶机${head ? ' <i>爆头</i>' : ''}`);
      this.updateHud();
    }
  }
  feed(html) {
    const d = document.createElement('div'); d.innerHTML = html; $('killfeed').appendChild(d);
    setTimeout(() => d.remove(), 4000);
    while ($('killfeed').children.length > 5) $('killfeed').firstChild.remove();
  }
  addDecal(pt, n) {
    let d = this.decals[this.decalIdx];
    if (!d) { d = new THREE.Mesh(this.decalGeo, this.decalMat); this.scene.add(d); this.decals[this.decalIdx] = d; }
    this.decalIdx = (this.decalIdx + 1) % 40;
    d.position.copy(pt).addScaledVector(n, 0.012);
    d.lookAt(pt.clone().add(n)); d.rotateZ(Math.random() * 6.28);
    const s = 0.7 + Math.random() * 0.8; d.scale.set(s, s, 1);
  }
  sparks(pt, n, count, color) {
    for (let i = 0; i < count; i++) {
      const p = this.parts[this.partIdx]; this.partIdx = (this.partIdx + 1) % this.parts.length;
      p.m.visible = true; p.m.position.copy(pt); p.m.material.color.set(color);
      p.v.set((Math.random() - 0.5) * 3, Math.random() * 3, (Math.random() - 0.5) * 3).addScaledVector(n, 3);
      p.life = 0.25 + Math.random() * 0.25;
    }
  }
  addTracer(a, b) {
    const t = this.tracers[this.tracerIdx]; this.tracerIdx = (this.tracerIdx + 1) % this.tracers.length;
    const len = a.distanceTo(b); if (len < 0.5) return;
    t.m.visible = true; t.m.position.copy(a).add(b).multiplyScalar(0.5);
    t.m.scale.set(0.012, 0.012, len); t.m.lookAt(b); t.life = 0.06;
  }
  throwGrenade() {
    if (this.grenades <= 0 || this.swapT > 0) return;
    this.grenades--; this.updateAmmo();
    this.camera.updateMatrixWorld(true);
    const fwd = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8), new THREE.MeshStandardMaterial({ color: 0x2f4a2a, metalness: 0.5, roughness: 0.5 }));
    const pos = new THREE.Vector3().setFromMatrixPosition(this.camera.matrixWorld).addScaledVector(fwd, 0.5);
    m.position.copy(pos); this.scene.add(m);
    const vel = fwd.clone().multiplyScalar(16).add(new THREE.Vector3(this.p.vx, 3.2, this.p.vz));
    this.grenList.push({ m, pos, vel, t: 2.2 });
    sfx.switchW();
  }
  updateGrenades(dt) {
    for (let i = this.grenList.length - 1; i >= 0; i--) {
      const g = this.grenList[i];
      g.t -= dt; g.vel.y -= GRAV * dt;
      g.pos.addScaledVector(g.vel, dt);
      const r = 0.1;
      if (g.pos.y < r) { g.pos.y = r; g.vel.y *= -0.35; g.vel.x *= 0.75; g.vel.z *= 0.75; if (Math.abs(g.vel.y) > 1) sfx.wall(); }
      for (const c of this.world.colliders) {
        if (g.pos.x > c.minX - r && g.pos.x < c.maxX + r && g.pos.y > c.minY - r && g.pos.y < c.maxY + r && g.pos.z > c.minZ - r && g.pos.z < c.maxZ + r) {
          const px = Math.min(g.pos.x - (c.minX - r), c.maxX + r - g.pos.x), py = Math.min(g.pos.y - (c.minY - r), c.maxY + r - g.pos.y), pz = Math.min(g.pos.z - (c.minZ - r), c.maxZ + r - g.pos.z);
          if (px <= py && px <= pz) { g.vel.x *= -0.5; g.pos.x += (g.pos.x - (c.minX + c.maxX) / 2 > 0 ? px : -px); }
          else if (py <= pz) { g.vel.y *= -0.4; g.vel.x *= 0.8; g.vel.z *= 0.8; g.pos.y += (g.pos.y - (c.minY + c.maxY) / 2 > 0 ? py : -py); }
          else { g.vel.z *= -0.5; g.pos.z += (g.pos.z - (c.minZ + c.maxZ) / 2 > 0 ? pz : -pz); }
          sfx.metal();
        }
      }
      g.m.position.copy(g.pos);
      if (g.t <= 0) { this.explode(g.pos); this.scene.remove(g.m); this.grenList.splice(i, 1); }
    }
  }
  explode(pos) {
    sfx.explode();
    this.boomPos.copy(pos); this.boomT = 0.45; this.boom.visible = true;
    this.flashLight.position.copy(pos); this.flashLight.intensity = 12; this.flashT = 0.12; this.flashAtWorld = true;
    this.sparks(pos, new THREE.Vector3(0, 1, 0), 24, 0xffa040);
    for (const b of this.bots) {
      if (!b.alive) continue;
      const d = Math.hypot(b.x - pos.x, 0.9 - pos.y, b.z - pos.z);
      if (d < 8) this.damageBot(b, 170 * (1 - d / 8), false, '手雷');
    }
    const dp = Math.hypot(this.p.x - pos.x, this.p.y + 1 - pos.y, this.p.z - pos.z);
    if (dp < 12) this.shake = Math.max(this.shake, (1 - dp / 12) * 0.9);
  }

  // ---------- 主循环 ----------
  loop(now) {
    if (!this.running) { return; }
    const interval = 1000 / this.S.fps - 1.5;
    if (now - this.lastT < interval) return;
    let dt = (now - this.lastT) / 1000; this.lastT = now;
    dt = Math.min(dt, 0.05);
    if (!this.paused) this.update(dt);
    this.sky.position.copy(this.camera.position);
    this.sky.material.uniforms.time.value += dt;
    this.renderer.render(this.scene, this.camera);
    this.frames++; this.fpsT += dt;
    if (this.fpsT >= 0.5) { if (this.S.showFps) $('fpsBox').textContent = Math.round(this.frames / this.fpsT) + ' FPS'; this.frames = 0; this.fpsT = 0; }
  }

  update(dt) {
    const p = this.p, inp = this.inp, w = this.W, S = this.S;
    // --- 瞄准/视野
    const scoped = w.zoom && this.adsT > 0.85;
    if (inp.adsTap) { inp.adsTap = false; if (!this.reloading && this.swapT <= 0) { this.ads = !this.ads; } }
    if (inp.zoomTap) { inp.zoomTap = false; if (w.zoom) this.zoomIdx = (this.zoomIdx + 1) % w.zoom.length; }
    this.adsT = clamp(this.adsT + (this.ads ? 1 : -1) * dt * (w.zoom ? 6 : 9), 0, 1);
    const baseFov = S.fov;
    const adsFov = w.zoom ? w.zoom[this.zoomIdx] : w.adsFov * (baseFov / 75);
    const fovT = lerp(baseFov, adsFov, this.adsT);
    if (Math.abs(this.camera.fov - fovT) > 0.01) { this.camera.fov = fovT; this.camera.updateProjectionMatrix(); }
    const fovScale = clamp(Math.tan(this.camera.fov * Math.PI / 360) / Math.tan(baseFov * Math.PI / 360), 0.08, 1);
    const sensBase = scoped ? (this.zoomIdx ? S.sensScope2 : S.sensScope) : this.ads ? S.sensAds : S.sensLook;
    const k = 0.0024 * sensBase * fovScale;
    p.yaw -= inp.lookX * k * S.sensX; p.pitch -= inp.lookY * k * S.sensY;
    p.yaw += inp.gyroYaw * fovScale; p.pitch += inp.gyroPitch * fovScale;
    inp.lookX = inp.lookY = inp.gyroYaw = inp.gyroPitch = 0;
    p.pitch = clamp(p.pitch, -1.5, 1.5);

    // --- 蹲下 / 跳跃
    if (inp.crouchTap) { inp.crouchTap = false; if (!p.crouch) p.crouch = true; else if (this.canStand()) p.crouch = false; }
    const h = p.crouch ? H_CROUCH : H_STAND;
    p.eye = lerp(p.eye, p.crouch ? EYE_CROUCH : EYE_STAND, Math.min(1, dt * 12));
    const gh0 = this.groundAt(p.x, p.y, p.z, RADIUS);
    if (inp.jump) { inp.jump = false; if (p.y - gh0 < 0.3 && p.vy <= 0.5 && !p.crouch) { p.vy = JUMP; p.ground = false; sfx.jump(); } }

    // --- 水平移动
    const sy = Math.sin(p.yaw), cy = Math.cos(p.yaw);
    const fx = -sy, fz = -cy, rx = cy, rz = -sy;
    const mag = Math.min(1, Math.hypot(inp.mx, inp.my));
    let wx = fx * inp.my + rx * inp.mx, wz = fz * inp.my + rz * inp.mx;
    const wl = Math.hypot(wx, wz) || 1; wx /= wl; wz /= wl;
    const maxSp = 5.2 * w.speed * (p.crouch ? 0.5 : 1) * (this.ads ? 0.65 : 1) * (mag > 0.01 ? Math.min(1, 0.35 + mag * 0.9) : 0);
    const acc = Math.min(1, dt * (p.ground ? 12 : 2.5));
    p.vx = lerp(p.vx, wx * maxSp, acc); p.vz = lerp(p.vz, wz * maxSp, acc);
    this.moveHoriz(p, p.vx * dt, p.vz * dt, RADIUS, h);

    // --- 垂直
    const gh = this.groundAt(p.x, p.y, p.z, RADIUS);
    const wasGround = p.ground;
    if (p.vy <= 0 && p.y <= gh + 0.001) { if (!wasGround && p.fallV < -6) sfx.land(); p.y = gh; p.vy = 0; p.ground = true; p.fallV = 0; }
    else {
      p.ground = false; p.vy -= GRAV * dt; p.fallV = p.vy;
      let ny = p.y + p.vy * dt;
      if (p.vy > 0) {
        for (const c of this.world.colliders) {
          if (c.minY >= p.y + h - 0.05 && c.minY <= ny + h) {
            const cx = clamp(p.x, c.minX, c.maxX), cz = clamp(p.z, c.minZ, c.maxZ);
            if ((p.x - cx) ** 2 + (p.z - cz) ** 2 < RADIUS * RADIUS) { p.vy = 0; ny = c.minY - h; break; }
          }
        }
      }
      if (ny < gh && p.vy <= 0) { ny = gh; p.vy = 0; p.ground = true; if (p.fallV < -6) sfx.land(); p.fallV = 0; }
      p.y = ny;
    }
    // 脚步
    const spd = Math.hypot(p.vx, p.vz);
    if (p.ground && spd > 0.5) { p.bob += dt * spd * 2.2; p.step += spd * dt; if (p.step > (p.crouch ? 2.6 : 1.9)) { p.step = 0; sfx.step(p.crouch ? 0.4 : 1); } }
    else p.bob = lerp(p.bob, Math.round(p.bob / Math.PI) * Math.PI, dt * 8);

    // --- 武器逻辑
    this.fireCool = Math.max(0, this.fireCool - dt);
    this.bloom = Math.max(0, this.bloom - dt * 0.06);
    if (this.swapT > 0) {
      const before = this.swapT; this.swapT -= dt;
      if (before > 0.21 && this.swapT <= 0.21 && this.swapPending >= 0) { this.cur = this.swapPending; this.swapPending = -1; this.zoomIdx = 0; this.equipModel(); }
      if (this.swapT < 0) this.swapT = 0;
    }
    if (inp.sw) { inp.sw = false; this.switchWeapon(); }
    if (inp.reload) { inp.reload = false; this.startReload(); }
    if (inp.grenade) { inp.grenade = false; this.throwGrenade(); }
    if (this.reloading) {
      this.reloadT += dt;
      if (this.reloadT >= this.W.reload) {
        const s = this.slot, ww = this.W, need = ww.mag - s.mag, take = Math.min(need, s.reserve);
        s.mag += take; s.reserve -= take; this.reloading = false; this.updateAmmo();
      }
    }
    if (this.startReloadSoon > 0) { this.startReloadSoon -= dt; if (this.startReloadSoon <= 0) this.startReload(); }
    if (!inp.fire) this.semiLock = false;
    if (inp.fire && this.swapT <= 0 && !this.reloading && this.fireCool <= 0) {
      const wp = this.W;
      if (this.slot.mag <= 0) { if (!this.semiLock) { sfx.dry(); this.semiLock = true; } this.startReload(); }
      else if (wp.auto || !this.semiLock) { this.fire(); if (!wp.auto) this.semiLock = true; }
    }
    this.grenT += dt; if (this.grenT > 12) { this.grenT = 0; if (this.grenades < 3) { this.grenades++; this.updateAmmo(); } }

    // --- 相机与枪模型
    this.camera.position.set(p.x, p.y + p.eye + Math.sin(p.bob * 2) * 0.012 * Math.min(1, spd / 4), p.z);
    let sx = 0, sz = 0;
    if (this.shake > 0.001) { sx = (Math.random() - 0.5) * this.shake * 0.04; sz = (Math.random() - 0.5) * this.shake * 0.04; this.shake *= Math.pow(0.002, dt); }
    this.camera.rotation.set(p.pitch + sx, p.yaw + sz, 0);
    this.kickZ = Math.max(0, this.kickZ - dt * 0.5); this.kickRot = Math.max(0, this.kickRot - dt * 1.4);
    const adsY = this.model.userData.adsY;
    const bobX = Math.sin(p.bob) * 0.008 * (1 - this.adsT), bobY = Math.abs(Math.cos(p.bob)) * 0.006 * (1 - this.adsT);
    let oy = 0, rotX = this.kickRot, rotZ = 0;
    if (this.reloading) { const f = this.reloadT / this.W.reload; const s = Math.sin(f * Math.PI); oy -= 0.12 * s; rotX -= 0.5 * s; rotZ += 0.35 * s; }
    if (this.swapT > 0) { const f = this.swapT / 0.42; oy -= 0.3 * Math.sin(f * Math.PI); }
    this.vm.position.set(lerp(0.17, 0, this.adsT) + bobX, lerp(-0.19, adsY, this.adsT) + bobY + oy, lerp(-0.4, -0.32, this.adsT) + this.kickZ);
    this.vm.rotation.set(rotX, 0, rotZ);
    this.vm.visible = !(w.zoom && this.adsT > 0.9);
    // 枪口火焰
    if (this.flashT > 0) {
      this.flashT -= dt;
      if (!this.flashAtWorld) {
        this.flashMesh.visible = true; this.flashMesh.rotation.z = Math.random() * 6; const sc = 0.7 + Math.random() * 0.8; this.flashMesh.scale.set(sc, sc, sc);
        if (this.q.flash) { this.model.userData.muzzle.getWorldPosition(this.flashLight.position); this.flashLight.intensity = 6; }
      }
      if (this.flashT <= 0) { this.flashMesh.visible = false; this.flashLight.intensity = 0; this.flashAtWorld = false; }
    }
    // 爆炸球
    if (this.boomT > 0) {
      this.boomT -= dt; const f = 1 - this.boomT / 0.45;
      this.boom.position.copy(this.boomPos); this.boom.scale.setScalar(0.5 + f * 5); this.boom.material.opacity = 0.7 * (1 - f);
      if (this.boomT <= 0) this.boom.visible = false;
    }
    // 粒子与曳光
    for (const pt of this.parts) if (pt.m.visible) { pt.life -= dt; pt.v.y -= 9 * dt; pt.m.position.addScaledVector(pt.v, dt); if (pt.life <= 0) pt.m.visible = false; }
    for (const t of this.tracers) if (t.m.visible) { t.life -= dt; if (t.life <= 0) t.m.visible = false; }

    this.updateGrenades(dt);
    this.updateBots(dt);

    // 计时
    this.elapsed += dt;
    if (this.cfg.mode === 'kill') {
      this.timeLeft -= dt;
      if (this.timeLeft <= 0) { this.timeLeft = 0; this.finish(); return; }
    }
    this.updateHudFrame(spd);
  }

  finish() {
    this.running = false; this.inp.fire = false;
    if (this.onEnd) this.onEnd({ kills: this.kills, heads: this.heads, shots: this.shots, hits: this.hits });
  }

  // ---------- HUD ----------
  updateAmmo() {
    const s = this.slot;
    $('ammoMag').textContent = s.mag; $('ammoRes').textContent = s.reserve; $('gren').textContent = this.grenades;
    $('wName').textContent = this.W.name;
  }
  updateHud() {
    $('kills').textContent = this.kills; $('hpFill').style.width = this.p.hp + '%'; $('hpText').textContent = this.p.hp; this.updateAmmo();
  }
  updateHudFrame(spd) {
    const t = this.cfg.mode === 'kill' ? this.timeLeft : this.elapsed;
    const m = Math.floor(t / 60), s = Math.floor(t % 60);
    const str = `${m}:${s < 10 ? '0' : ''}${s}`;
    if (str !== this.lastTimeStr) { $('timer').textContent = str; this.lastTimeStr = str; }
    const w = this.W;
    const scoped = w.zoom && this.adsT > 0.85;
    $('scope').style.display = scoped ? 'block' : 'none';
    const focal = (window.innerHeight / 2) / Math.tan(this.camera.fov * Math.PI / 360);
    const gap = Math.min(120, 4 + Math.tan(this.spreadNow()) * focal);
    const ch = $('crosshair'); ch.style.setProperty('--gap', gap.toFixed(1) + 'px');
    ch.style.display = scoped ? 'none' : 'block';
    $('reloadBar').style.display = this.reloading ? 'block' : 'none';
    if (this.reloading) $('reloadFill').style.width = (this.reloadT / w.reload * 100).toFixed(0) + '%';
    $('zoomBtn').style.display = w.zoom ? '' : 'none';
    this.mmDirty += 1; if (this.mmDirty % 4 === 0) this.drawMinimap();
  }
  buildMinimapStatic() {
    const c = document.createElement('canvas'); c.width = c.height = 360; const x = c.getContext('2d');
    x.fillStyle = '#16202a'; x.fillRect(0, 0, 360, 360);
    x.fillStyle = '#2d3a46'; x.fillRect(0, 175, 360, 10); x.fillRect(175, 0, 10, 360);
    for (const col of this.world.colliders) {
      if (col.maxY - col.minY < 0.8 || col.minY > 0.5) continue;
      x.fillStyle = col.maxY > 3 ? '#8fa3b5' : '#5f7387';
      x.fillRect((col.minX + 45) * 4, (col.minZ + 45) * 4, Math.max(2, (col.maxX - col.minX) * 4), Math.max(2, (col.maxZ - col.minZ) * 4));
    }
    this.mmStatic = c;
  }
  drawMinimap() {
    const cv = $('mm'); const x = cv.getContext('2d'); const S = cv.width, c = S / 2, k = 2.5;
    x.clearRect(0, 0, S, S);
    x.save(); x.beginPath(); x.arc(c, c, c - 1, 0, 7); x.clip();
    x.fillStyle = '#0c1218'; x.fillRect(0, 0, S, S);
    x.translate(c, c); x.rotate(this.p.yaw); x.scale(k / 4, k / 4); x.translate(-(this.p.x + 45) * 4, -(this.p.z + 45) * 4);
    x.drawImage(this.mmStatic, 0, 0);
    for (const b of this.bots) if (b.alive) { x.fillStyle = '#ff4a3a'; x.beginPath(); x.arc((b.x + 45) * 4, (b.z + 45) * 4, 9, 0, 7); x.fill(); }
    x.restore();
    x.fillStyle = '#ffd24a'; x.beginPath(); x.moveTo(c, c - 7); x.lineTo(c - 5, c + 5); x.lineTo(c + 5, c + 5); x.closePath(); x.fill();
  }
}
