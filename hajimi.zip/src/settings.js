const KEY = 'hajimi.settings.v1';

export const DEFAULT_LAYOUT = {
  fire:    { x: 88, y: 58, s: 88 },
  ads:     { x: 76, y: 36, s: 64 },
  jump:    { x: 94, y: 34, s: 62 },
  crouch:  { x: 94, y: 82, s: 58 },
  reload:  { x: 78, y: 82, s: 58 },
  switch:  { x: 66, y: 88, s: 52 },
  grenade: { x: 66, y: 68, s: 54 },
  zoom:    { x: 66, y: 46, s: 50 },
  pause:   { x: 96, y: 8,  s: 40 }
};

export const defaults = {
  sensLook: 1.0, sensAds: 0.7, sensScope: 0.5, sensScope2: 0.3, sensX: 1.0, sensY: 1.0,
  gyro: 'off', gyroSens: 1.0, gyroInvert: false,
  quality: 'medium', fps: 60, fov: 75, showFps: false,
  btnScale: 1.0, btnOpacity: 0.65,
  layoutSlot: 'A',
  layouts: { A: null, B: null, C: null },
  primary: 'ak47', secondary: 'deagle',
  skins: {},
  tod: 'day', mode: 'practice', targets: 6, diff: 1
};

export function loadSettings() {
  let s = {};
  try { s = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { s = {}; }
  const out = Object.assign({}, defaults, s);
  out.layouts = Object.assign({ A: null, B: null, C: null }, s.layouts || {});
  out.skins = Object.assign({}, s.skins || {});
  return out;
}

export function saveSettings(s) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* ignore */ }
}

export function getLayout(s) {
  const base = JSON.parse(JSON.stringify(DEFAULT_LAYOUT));
  const cur = s.layouts[s.layoutSlot];
  if (cur) for (const k in cur) if (base[k]) Object.assign(base[k], cur[k]);
  return base;
}
