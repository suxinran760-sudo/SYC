import * as THREE from 'three';

export const SKINS = [
  { name: '经典', color: 0x2b2e33 },
  { name: '沙漠', color: 0x9a8456 },
  { name: '丛林', color: 0x3d5a3a },
  { name: '黄金', color: 0xc9a227 }
];

// fov: 开镜视野(度)；zoom: 狙击多倍率 fov 列表
export const WEAPONS = {
  ak47: {
    name: 'AK47', cn: '突击步枪', type: 'rifle', dmg: 36, pellets: 1, rpm: 600, mag: 30, reserve: 120,
    reload: 2.4, spreadHip: 0.022, spreadAds: 0.006, recoil: 0.0105, auto: true, range: 220, adsFov: 55, speed: 0.95,
    headMul: 2.6,
    model: { bw: 0.055, bh: 0.085, bl: 0.5, blen: 0.32, br: 0.014, guard: [0.07, 0.07, 0.26, true], stock: [0.045, 0.1, 0.3, true], mag: [0.04, 0.2, 0.075, -0.02, 0.3], sight: 'iron' }
  },
  m4a1: {
    name: 'M4A1', cn: '突击步枪', type: 'rifle', dmg: 31, pellets: 1, rpm: 720, mag: 30, reserve: 120,
    reload: 2.1, spreadHip: 0.02, spreadAds: 0.005, recoil: 0.0085, auto: true, range: 220, adsFov: 52, speed: 1.0,
    headMul: 2.6,
    model: { bw: 0.05, bh: 0.09, bl: 0.45, blen: 0.3, br: 0.013, guard: [0.065, 0.065, 0.26, false], stock: [0.04, 0.1, 0.26, false], mag: [0.04, 0.17, 0.07, 0, 0.1], sight: 'red' }
  },
  awm: {
    name: 'AWM', cn: '狙击枪', type: 'sniper', dmg: 120, pellets: 1, rpm: 42, mag: 5, reserve: 25,
    reload: 3.2, spreadHip: 0.07, spreadAds: 0.0005, recoil: 0.04, auto: false, range: 500, adsFov: 20, zoom: [20, 7], speed: 0.85,
    headMul: 3.0, scope: true,
    model: { bw: 0.06, bh: 0.09, bl: 0.6, blen: 0.5, br: 0.016, guard: null, stock: [0.06, 0.13, 0.4, false], mag: [0.04, 0.1, 0.09, 0.05, 0], sight: 'big', bolt: true }
  },
  barrett: {
    name: '巴雷特', cn: '狙击枪', type: 'sniper', dmg: 150, pellets: 1, rpm: 90, mag: 10, reserve: 30,
    reload: 3.8, spreadHip: 0.09, spreadAds: 0.0006, recoil: 0.055, auto: false, range: 600, adsFov: 14, zoom: [14, 5], speed: 0.8,
    headMul: 3.0, scope: true,
    model: { bw: 0.075, bh: 0.11, bl: 0.75, blen: 0.55, br: 0.02, guard: null, stock: [0.07, 0.12, 0.3, false], mag: [0.05, 0.12, 0.2, -0.05, 0], sight: 'big', brake: true }
  },
  mp5: {
    name: 'MP5', cn: '冲锋枪', type: 'smg', dmg: 24, pellets: 1, rpm: 800, mag: 30, reserve: 150,
    reload: 1.9, spreadHip: 0.026, spreadAds: 0.01, recoil: 0.007, auto: true, range: 120, adsFov: 58, speed: 1.05,
    headMul: 2.2,
    model: { bw: 0.05, bh: 0.08, bl: 0.38, blen: 0.18, br: 0.013, guard: [0.06, 0.06, 0.2, false], stock: [0.035, 0.09, 0.22, false], mag: [0.035, 0.18, 0.05, 0.02, 0.1], sight: 'iron' }
  },
  deagle: {
    name: '沙漠之鹰', cn: '手枪', type: 'pistol', dmg: 58, pellets: 1, rpm: 220, mag: 7, reserve: 35,
    reload: 1.8, spreadHip: 0.018, spreadAds: 0.004, recoil: 0.03, auto: false, range: 150, adsFov: 58, speed: 1.05,
    headMul: 2.8,
    model: { bw: 0.04, bh: 0.065, bl: 0.28, blen: 0.08, br: 0.016, guard: null, stock: null, mag: [0.03, 0.1, 0.05, 0.05, 0.15], sight: 'iron', pistol: true }
  },
  shotgun: {
    name: '霰弹枪', cn: '霰弹枪', type: 'shotgun', dmg: 13, pellets: 9, rpm: 75, mag: 8, reserve: 32,
    reload: 2.8, spreadHip: 0.055, spreadAds: 0.04, recoil: 0.045, auto: false, range: 60, adsFov: 62, speed: 0.95,
    headMul: 1.8,
    model: { bw: 0.05, bh: 0.07, bl: 0.45, blen: 0.5, br: 0.017, guard: [0.07, 0.05, 0.2, true], stock: [0.045, 0.1, 0.3, true], mag: null, sight: 'iron', pump: true }
  }
};

export const WEAPON_ORDER = ['ak47', 'm4a1', 'awm', 'barrett', 'mp5', 'deagle', 'shotgun'];

export function buildWeaponModel(id, skin = 0, withHands = true) {
  const w = WEAPONS[id], m = w.model;
  const g = new THREE.Group();
  const metal = new THREE.MeshStandardMaterial({ color: SKINS[skin].color, metalness: 0.85, roughness: 0.38 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x15171a, metalness: 0.7, roughness: 0.5 });
  const woodM = new THREE.MeshStandardMaterial({ color: 0x6b4423, metalness: 0.05, roughness: 0.75 });
  const skinM = new THREE.MeshStandardMaterial({ color: 0xc89a78, roughness: 0.8 });
  const sleeveM = new THREE.MeshStandardMaterial({ color: 0x2c3a2a, roughness: 0.9 });
  const lens = new THREE.MeshStandardMaterial({ color: 0x4488ff, metalness: 0.9, roughness: 0.05, emissive: 0x112244 });

  const box = (mat, bw, bh, bl, x, y, z, rx = 0) => {
    const me = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bl), mat);
    me.position.set(x, y, z); me.rotation.x = rx; g.add(me); return me;
  };
  const cyl = (mat, r, len, x, y, z) => {
    const me = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 12), mat);
    me.rotation.x = Math.PI / 2; me.position.set(x, y, z); g.add(me); return me;
  };

  box(metal, m.bw, m.bh, m.bl, 0, 0, 0);
  box(dark, m.bw * 0.9, m.bh * 0.3, m.bl * 0.9, 0, m.bh * 0.5, 0);               // 机匣顶盖
  cyl(dark, m.br, m.blen, 0, m.bh * 0.15, -m.bl / 2 - m.blen / 2);                  // 枪管
  if (m.brake) cyl(dark, m.br * 1.7, 0.1, 0, m.bh * 0.15, -m.bl / 2 - m.blen + 0.03);
  const muzzleZ = -m.bl / 2 - m.blen;
  if (m.guard) box(m.guard[3] ? woodM : dark, m.guard[0], m.guard[1], m.guard[2], 0, m.bh * 0.1, -m.bl / 2 - m.guard[2] / 2 + 0.03);
  if (m.stock) {
    const st = box(m.stock[3] ? woodM : dark, m.stock[0], m.stock[1], m.stock[2], 0, -m.stock[1] * 0.2, m.bl / 2 + m.stock[2] / 2 - 0.02);
    st.rotation.x = -0.08;
  }
  if (m.mag) box(dark, m.mag[0], m.mag[1], m.mag[2], 0, -m.bh / 2 - m.mag[1] / 2 + 0.02, m.mag[3], m.mag[4]);
  // 握把
  box(m.pistol ? dark : woodM, 0.04, 0.1, 0.05, 0, -m.bh / 2 - 0.04, m.bl / 2 - 0.06, 0.3);
  box(dark, 0.012, 0.03, 0.09, 0, -m.bh / 2 - 0.005, m.bl / 2 - 0.16); // 扳机护圈
  // 瞄具
  const topY = m.bh * 0.65;
  if (m.sight === 'iron') {
    box(dark, 0.012, 0.022, 0.012, 0, topY + 0.01, muzzleZ + 0.1);
    box(dark, 0.03, 0.02, 0.012, 0, topY + 0.005, m.bl / 2 - 0.08);
  } else if (m.sight === 'red') {
    box(dark, 0.035, 0.04, 0.07, 0, topY + 0.02, -0.02);
    box(lens, 0.03, 0.03, 0.004, 0, topY + 0.025, -0.055);
  } else if (m.sight === 'big') {
    const sc = cyl(dark, 0.03, 0.3, 0, topY + 0.05, -0.05);
    cyl(dark, 0.04, 0.07, 0, topY + 0.05, -0.2);
    cyl(dark, 0.036, 0.06, 0, topY + 0.05, 0.1);
    cyl(lens, 0.026, 0.004, 0, topY + 0.05, -0.236);
    box(dark, 0.02, 0.05, 0.04, 0, topY + 0.015, -0.05);
  }
  if (m.bolt) box(dark, 0.07, 0.02, 0.02, 0.04, 0.02, 0.05);
  if (m.pump) box(woodM, 0.06, 0.05, 0.16, 0, -0.03, -m.bl / 2 - 0.12);

  // 手臂
  if (withHands) {
    const lh = box(skinM, 0.07, 0.07, 0.12, 0, -m.bh / 2 - 0.045, m.guard ? -m.bl / 2 - 0.05 : -0.1);
    lh.rotation.x = 0.1;
    const ls = box(sleeveM, 0.085, 0.085, 0.3, -0.03, -m.bh / 2 - 0.12, -0.05 + (m.guard ? -m.bl / 2 + 0.2 : 0.15), 0.35);
    ls.position.x = -0.05;
    box(skinM, 0.06, 0.07, 0.1, 0.012, -m.bh / 2 - 0.08, m.bl / 2 - 0.06);
    box(sleeveM, 0.085, 0.085, 0.3, 0.07, -m.bh / 2 - 0.16, m.bl / 2 + 0.1, -0.3);
  }

  const muzzle = new THREE.Object3D();
  muzzle.position.set(0, m.bh * 0.15, muzzleZ - 0.02);
  g.add(muzzle);
  g.userData.muzzle = muzzle;
  g.userData.adsY = -(topY + (m.sight === 'big' ? 0.06 : m.sight === 'red' ? 0.035 : 0.02));
  g.traverse(o => { if (o.isMesh) { o.castShadow = false; o.frustumCulled = false; } });
  return g;
}
