let ctx = null, noiseBuf = null;

export function initAudio() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  if (ctx.state === 'suspended') ctx.resume();
}

function burst(o) {
  if (!ctx) return;
  const { dur = 0.2, freq = 1800, q = 0.7, type = 'lowpass', gain = 0.6, sweep = 0, tone = 0, toneFreq = 120, vol = 1 } = o;
  const t = ctx.currentTime;
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  src.playbackRate.value = 0.8 + Math.random() * 0.4;
  const f = ctx.createBiquadFilter();
  f.type = type; f.Q.value = q;
  f.frequency.setValueAtTime(freq, t);
  if (sweep) f.frequency.exponentialRampToValueAtTime(Math.max(40, freq * sweep), t + dur);
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain * vol, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  src.connect(f); f.connect(g); g.connect(ctx.destination);
  src.start(t, Math.random() * 0.4, dur + 0.05);
  if (tone) {
    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(toneFreq * 2, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, toneFreq * 0.5), t + dur);
    const og = ctx.createGain();
    og.gain.setValueAtTime(tone * vol, t);
    og.gain.exponentialRampToValueAtTime(0.001, t + dur);
    osc.connect(og); og.connect(ctx.destination);
    osc.start(t); osc.stop(t + dur + 0.05);
  }
}

function beep(freq, dur, gain = 0.2, type = 'sine', delay = 0) {
  if (!ctx) return;
  const t = ctx.currentTime + delay;
  const o = ctx.createOscillator();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g); g.connect(ctx.destination);
  o.start(t); o.stop(t + dur + 0.02);
}

const SHOT = {
  rifle:   { dur: 0.22, freq: 3200, gain: 0.7, sweep: 0.15, tone: 0.6, toneFreq: 90 },
  smg:     { dur: 0.14, freq: 3800, gain: 0.55, sweep: 0.2, tone: 0.4, toneFreq: 130 },
  sniper:  { dur: 0.6, freq: 2400, gain: 0.95, sweep: 0.06, tone: 0.9, toneFreq: 60 },
  pistol:  { dur: 0.25, freq: 2600, gain: 0.75, sweep: 0.12, tone: 0.7, toneFreq: 100 },
  shotgun: { dur: 0.42, freq: 2000, gain: 0.95, sweep: 0.08, tone: 0.85, toneFreq: 70 }
};

export const sfx = {
  shot(kind) { burst(SHOT[kind] || SHOT.rifle); },
  dry() { burst({ dur: 0.05, freq: 3000, type: 'highpass', gain: 0.25 }); },
  reload(total = 2) {
    const click = () => burst({ dur: 0.05, freq: 2500, type: 'highpass', gain: 0.3, tone: 0.2, toneFreq: 300 });
    click();
    setTimeout(() => burst({ dur: 0.12, freq: 500, gain: 0.35, tone: 0.3, toneFreq: 160 }), total * 350);
    setTimeout(click, total * 700);
  },
  step(v = 1) { burst({ dur: 0.09, freq: 450, gain: 0.16, vol: v }); },
  jump() { burst({ dur: 0.12, freq: 700, gain: 0.14 }); },
  land() { burst({ dur: 0.15, freq: 300, gain: 0.25, tone: 0.3, toneFreq: 70 }); },
  hit(head) { beep(head ? 1500 : 900, 0.07, 0.22, 'square'); },
  kill() { beep(700, 0.09, 0.22, 'square'); beep(1100, 0.12, 0.22, 'square', 0.09); },
  wall() { burst({ dur: 0.1, freq: 900, gain: 0.25 }); },
  metal() { burst({ dur: 0.14, freq: 4500, type: 'bandpass', q: 6, gain: 0.3, tone: 0.2, toneFreq: 900 }); },
  explode() { burst({ dur: 1.1, freq: 900, gain: 1, sweep: 0.05, tone: 1, toneFreq: 50 }); },
  switchW() { burst({ dur: 0.07, freq: 1800, type: 'highpass', gain: 0.25 }); },
  amb() {}
};
