import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

// ---------- 程序化 PBR 贴图（颜色 + 凹凸） ----------
function makeTex(size, drawFn, srgb = true) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  drawFn(c.getContext('2d'), size);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 4;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
function speckle(ctx, s, n, alpha, light) {
  for (let i = 0; i < n; i++) {
    const v = light ? 160 + Math.random() * 95 : Math.random() * 90;
    ctx.fillStyle = `rgba(${v},${v},${v},${alpha * Math.random()})`;
    const r = 0.5 + Math.random() * 1.8;
    ctx.fillRect(Math.random() * s, Math.random() * s, r, r);
  }
}
const rnd = (a, b) => a + Math.random() * (b - a);

function brickSet(s = 256) {
  const rows = 8, bw = s / 4, bh = s / rows;
  const draw = (bump) => (ctx) => {
    ctx.fillStyle = bump ? '#222' : '#a9a294'; ctx.fillRect(0, 0, s, s);
    for (let r = 0; r < rows; r++) {
      const off = (r % 2) * bw / 2;
      for (let c = -1; c < 5; c++) {
        const x = c * bw + off, y = r * bh;
        if (bump) { const v = 150 + rnd(-25, 25); ctx.fillStyle = `rgb(${v},${v},${v})`; }
        else { ctx.fillStyle = `rgb(${rnd(135, 175)|0},${rnd(62, 82)|0},${rnd(42, 58)|0})`; }
        ctx.fillRect(x + 2, y + 2, bw - 4, bh - 4);
      }
    }
    speckle(ctx, s, 900, 0.25, false); speckle(ctx, s, 400, 0.15, true);
  };
  return { map: makeTex(s, draw(false)), bump: makeTex(s, draw(true), false) };
}
function concreteSet(s = 256, tint = [150, 150, 146]) {
  const draw = (bump) => (ctx) => {
    ctx.fillStyle = bump ? '#888' : `rgb(${tint[0]},${tint[1]},${tint[2]})`; ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 60; i++) {
      const v = bump ? 120 + rnd(-40, 40) : tint[0] + rnd(-18, 18);
      ctx.fillStyle = `rgba(${v},${v},${v},0.25)`;
      ctx.beginPath(); ctx.arc(Math.random() * s, Math.random() * s, rnd(4, 26), 0, 7); ctx.fill();
    }
    speckle(ctx, s, 2500, 0.35, false); speckle(ctx, s, 1500, 0.3, true);
    if (!bump) { // 划痕/裂缝
      ctx.strokeStyle = 'rgba(40,40,40,0.35)'; ctx.lineWidth = 1;
      for (let i = 0; i < 5; i++) {
        let x = Math.random() * s, y = Math.random() * s; ctx.beginPath(); ctx.moveTo(x, y);
        for (let k = 0; k < 8; k++) { x += rnd(-14, 14); y += rnd(4, 18); ctx.lineTo(x, y); }
        ctx.stroke();
      }
    }
  };
  return { map: makeTex(s, draw(false)), bump: makeTex(s, draw(true), false) };
}
function woodSet(s = 256) {
  const draw = (bump) => (ctx) => {
    const n = 5, pw = s / n;
    for (let i = 0; i < n; i++) {
      const b = rnd(-12, 12);
      ctx.fillStyle = bump ? `rgb(${150 + b},${150 + b},${150 + b})` : `rgb(${150 + b | 0},${105 + b | 0},${62 + b | 0})`;
      ctx.fillRect(i * pw, 0, pw, s);
      for (let k = 0; k < 28; k++) {
        const v = bump ? rnd(100, 190) : rnd(70, 120);
        ctx.fillStyle = bump ? `rgba(${v},${v},${v},0.3)` : `rgba(${v},${v * 0.65|0},${v * 0.35|0},0.3)`;
        ctx.fillRect(i * pw + rnd(0, pw), 0, rnd(0.5, 1.5), s);
      }
      ctx.fillStyle = bump ? '#222' : '#2a1a0c'; ctx.fillRect(i * pw, 0, 2, s);
    }
    ctx.fillStyle = bump ? '#333' : '#3a2812'; ctx.fillRect(0, 0, s, 8); ctx.fillRect(0, s - 8, s, 8);
  };
  return { map: makeTex(s, draw(false)), bump: makeTex(s, draw(true), false) };
}
function containerSet(color, s = 256) {
  const draw = (bump) => (ctx) => {
    ctx.fillStyle = bump ? '#999' : color; ctx.fillRect(0, 0, s, s);
    const n = 16, w = s / n;
    for (let i = 0; i < n; i++) {
      ctx.fillStyle = bump ? (i % 2 ? '#555' : '#ccc') : (i % 2 ? 'rgba(0,0,0,0.22)' : 'rgba(255,255,255,0.1)');
      ctx.fillRect(i * w, 0, w * 0.5, s);
    }
    speckle(ctx, s, 1500, 0.4, false);
    if (!bump) { ctx.fillStyle = 'rgba(120,60,20,0.25)'; for (let i = 0; i < 10; i++) ctx.fillRect(rnd(0, s), rnd(0, s), rnd(3, 20), rnd(8, 40)); }
  };
  return { map: makeTex(s, draw(false)), bump: makeTex(s, draw(true), false) };
}
function asphaltTex(s = 256) {
  return makeTex(s, (ctx) => {
    ctx.fillStyle = '#3b3d40'; ctx.fillRect(0, 0, s, s);
    speckle(ctx, s, 5000, 0.5, false); speckle(ctx, s, 2500, 0.4, true);
    ctx.fillStyle = '#d8c84a'; ctx.fillRect(s / 2 - 3, 0, 6, s * 0.5);
  });
}
function dirtTex(s = 256) {
  return makeTex(s, (ctx) => {
    ctx.fillStyle = '#6a6b4a'; ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 400; i++) {
      ctx.fillStyle = `rgba(${rnd(70, 120)|0},${rnd(80, 120)|0},${rnd(40, 70)|0},0.25)`;
      ctx.beginPath(); ctx.arc(Math.random() * s, Math.random() * s, rnd(2, 14), 0, 7); ctx.fill();
    }
    speckle(ctx, s, 3000, 0.4, false);
  });
}
function windowTex(s = 128) {
  return makeTex(s, (ctx) => {
    ctx.fillStyle = '#4a4f57'; ctx.fillRect(0, 0, s, s);
    for (let y = 0; y < 8; y++) for (let x = 0; x < 4; x++) {
      ctx.fillStyle = Math.random() < 0.35 ? '#ffd88a' : '#1d2430';
      ctx.fillRect(x * 32 + 4, y * 16 + 3, 24, 10);
    }
  });
}

// ---------- 地图生成 ----------
export function buildMap(scene, tod = 'day') {
  const groups = {};   // matKey -> geometry list
  const colliders = [];
  const extraMeshes = [];

  const brick = brickSet(), conc = concreteSet(), concDark = concreteSet(256, [105, 108, 112]), wood = woodSet();
  const cRed = containerSet('#8e2f27'), cBlue = containerSet('#2f5d8e'), cGreen = containerSet('#3f6b3a'), cOrange = containerSet('#c2731f');
  const mk = (set, rough = 0.9, metal = 0, bs = 1.2) => new THREE.MeshStandardMaterial({ map: set.map, bumpMap: set.bump, bumpScale: bs, roughness: rough, metalness: metal });
  const MAT = {
    brick: mk(brick, 0.95), concrete: mk(conc, 0.92), concDark: mk(concDark, 0.9), wood: mk(wood, 0.8, 0, 0.8),
    cRed: mk(cRed, 0.5, 0.55), cBlue: mk(cBlue, 0.5, 0.55), cGreen: mk(cGreen, 0.5, 0.55), cOrange: mk(cOrange, 0.5, 0.55),
    metal: new THREE.MeshStandardMaterial({ color: 0x555a60, metalness: 0.8, roughness: 0.45 }),
    trunk: new THREE.MeshStandardMaterial({ color: 0x4d3722, roughness: 1 }),
    leaf: new THREE.MeshStandardMaterial({ color: 0x3f6b2e, roughness: 1 }),
    lamp: new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff0c0, emissiveIntensity: tod === 'night' ? 3 : 0.4 }),
    far: new THREE.MeshStandardMaterial({ map: windowTex(), roughness: 1, emissive: 0xffffff, emissiveMap: windowTex(), emissiveIntensity: tod === 'night' ? 0.8 : 0.05 })
  };
  MAT.far.map.repeat.set(2, 6);
  MAT.far.emissiveMap.repeat.set(2, 6);

  const TILE = 2;
  function scaleUV(geo, w, h, d) {
    const uv = geo.attributes.uv;
    const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
    for (let f = 0; f < 6; f++) {
      const [fw, fh] = dims[f];
      for (let v = 0; v < 4; v++) { const i = f * 4 + v; uv.setXY(i, uv.getX(i) * fw / TILE, uv.getY(i) * fh / TILE); }
    }
    uv.needsUpdate = true;
  }
  // 盒子：中心 xz，底部 y，solid=是否有碰撞
  function B(mat, cx, y, cz, w, h, d, solid = true) {
    if (w <= 0.001 || h <= 0.001 || d <= 0.001) return;
    const g = new THREE.BoxGeometry(w, h, d);
    scaleUV(g, w, h, d);
    g.translate(cx, y + h / 2, cz);
    (groups[mat] ||= []).push(g);
    if (solid) colliders.push({ minX: cx - w / 2, maxX: cx + w / 2, minY: y, maxY: y + h, minZ: cz - d / 2, maxZ: cz + d / 2 });
  }
  function G(mat, geo, solidBox) {
    (groups[mat] ||= []).push(geo);
    if (solidBox) colliders.push(solidBox);
  }

  // 带门窗洞的墙。axis='x': 沿x延伸，固定z；axis='z': 沿z延伸，固定x
  function wall(axis, fixed, a, b, t, y0, h, mat, gaps = []) {
    const seg = (p, q) => {
      if (q - p < 0.02) return;
      if (axis === 'x') B(mat, (p + q) / 2, y0, fixed, q - p, h, t);
      else B(mat, fixed, y0, (p + q) / 2, t, h, q - p);
    };
    const piece = (p, q, yy, hh) => {
      if (hh < 0.05) return;
      if (axis === 'x') B(mat, (p + q) / 2, yy, fixed, q - p, hh, t);
      else B(mat, fixed, yy, (p + q) / 2, t, hh, q - p);
    };
    const sorted = gaps.slice().sort((p, q) => p.c - q.c);
    let cur = a;
    for (const g of sorted) {
      const s = g.c - g.w / 2, e = g.c + g.w / 2;
      seg(cur, s);
      if (g.type === 'door') piece(s, e, y0 + 2.5, h - 2.5);
      else if (g.type === 'gate') piece(s, e, y0 + 3.6, h - 3.6);
      else if (g.type === 'window') { piece(s, e, y0, 1.2); piece(s, e, y0 + 2.4, h - 2.4); }
      else if (g.type === 'high') { piece(s, e, y0, 3.2); piece(s, e, y0 + 4.4, h - 4.4); }
      cur = e;
    }
    seg(cur, b);
  }

  // ---- 地面、道路 ----
  const meshes = [];
  const dirt = dirtTex(); dirt.repeat.set(30, 30);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), new THREE.MeshStandardMaterial({ map: dirt, roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground); meshes.push(ground);
  const asph = asphaltTex();
  function road(cx, cz, len, wid, rotZ) {
    const t = asph.clone(); t.needsUpdate = true; t.repeat.set(len / 8, wid / 8); t.wrapS = t.wrapT = THREE.RepeatWrapping;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(len, wid), new THREE.MeshStandardMaterial({ map: t, roughness: 0.85 }));
    m.rotation.x = -Math.PI / 2; m.rotation.z = rotZ; m.position.set(cx, 0.02, cz); m.receiveShadow = true;
    scene.add(m); meshes.push(m);
  }
  road(0, 0, 90, 8, 0);
  road(0, 0, 90, 8, Math.PI / 2);

  // ---- 外围墙 ----
  const H = 45;
  B('concDark', 0, 0, -H, 2 * H + 2, 7, 1.2); B('concDark', 0, 0, H, 2 * H + 2, 7, 1.2);
  B('concDark', -H, 0, 0, 1.2, 7, 2 * H); B('concDark', H, 0, 0, 1.2, 7, 2 * H);

  // ---- 建筑 A：砖房（单层） ----
  { const cx = -24, cz = -17, w = 16, d = 12, h = 3.6, t = 0.4;
    wall('x', cz - d / 2, cx - w / 2, cx + w / 2, t, 0, h, 'brick', [{ c: cx - 4, w: 1.6, type: 'window' }, { c: cx + 4, w: 1.6, type: 'window' }]);
    wall('x', cz + d / 2, cx - w / 2, cx + w / 2, t, 0, h, 'brick', [{ c: cx - 3, w: 2.2, type: 'door' }, { c: cx + 5, w: 1.6, type: 'window' }]);
    wall('z', cx - w / 2, cz - d / 2, cz + d / 2, t, 0, h, 'brick', [{ c: cz - 3, w: 1.6, type: 'window' }, { c: cz + 3, w: 1.6, type: 'window' }]);
    wall('z', cx + w / 2, cz - d / 2, cz + d / 2, t, 0, h, 'brick', [{ c: cz + 1, w: 2.2, type: 'door' }]);
    wall('z', cx + 1, cz - d / 2, cz + d / 2, t, 0, h, 'brick', [{ c: cz + 2, w: 2.2, type: 'door' }, { c: cz - 3, w: 1.6, type: 'window' }]);
    B('concDark', cx, h, cz, w + 0.6, 0.3, d + 0.6);
    B('wood', cx - 5, 0, cz - 3.5, 1.2, 0.9, 1.2); B('wood', cx - 3.8, 0, cz - 3.5, 1.2, 0.9, 1.2); B('wood', cx - 5, 0.9, cz - 3.5, 1.2, 0.9, 1.2);
    B('wood', cx + 5, 0, cz + 3, 1.2, 1.2, 1.2);
  }
  // ---- 建筑 B：混凝土两层楼 ----
  { const cx = 22, cz = -18, w = 14, d = 14, t = 0.4, F = 3.3, UH = 3.2;
    wall('x', cz - d / 2, cx - w / 2, cx + w / 2, t, 0, F, 'concrete', [{ c: cx + 3, w: 1.6, type: 'window' }]);
    wall('x', cz + d / 2, cx - w / 2, cx + w / 2, t, 0, F, 'concrete', [{ c: cx + 2, w: 2.2, type: 'door' }, { c: cx - 3, w: 1.6, type: 'window' }]);
    wall('z', cx - w / 2, cz - d / 2, cz + d / 2, t, 0, F, 'concrete', [{ c: cz - 2, w: 2.2, type: 'door' }]);
    wall('z', cx + w / 2, cz - d / 2, cz + d / 2, t, 0, F, 'concrete', [{ c: cz - 3, w: 1.6, type: 'window' }, { c: cz + 3, w: 1.6, type: 'window' }]);
    // 楼板（带楼梯口）
    B('concrete', cx, F - 0.3, cz - 3.0, w, 0.3, 8.0);
    B('concrete', cx + 1.2, F - 0.3, cz + 3.9, w - 2.4, 0.3, 6.2);
    // 楼梯：沿西墙向北上行
    for (let i = 0; i < 12; i++) {
      const top = (i + 1) * (F / 12);
      B('concDark', cx - 5.6, 0, cz + 6.4 - (i + 0.5) * 0.45, 2.2, top, 0.45);
    }
    // 上层
    wall('x', cz - d / 2, cx - w / 2, cx + w / 2, t, F, UH, 'concrete', [{ c: cx - 3, w: 1.6, type: 'window' }, { c: cx + 3, w: 1.6, type: 'window' }]);
    wall('x', cz + d / 2, cx - w / 2, cx + w / 2, t, F, UH, 'concrete', [{ c: cx - 3, w: 1.6, type: 'window' }, { c: cx + 3, w: 1.6, type: 'window' }]);
    wall('z', cx - w / 2, cz - d / 2, cz + d / 2, t, F, UH, 'concrete', [{ c: cz, w: 1.6, type: 'window' }]);
    wall('z', cx + w / 2, cz - d / 2, cz + d / 2, t, F, UH, 'concrete', [{ c: cz - 3, w: 1.6, type: 'window' }, { c: cz + 3, w: 1.6, type: 'window' }]);
    wall('x', cz - 1, cx - 1, cx + w / 2, t, F, UH, 'concrete', [{ c: cx + 3, w: 2.2, type: 'door' }]);
    B('concDark', cx, F + UH, cz, w + 0.6, 0.3, d + 0.6);
    B('wood', cx + 4, F, cz + 4, 1.2, 0.9, 1.2);
    B('metal', cx - 3, 0, cz - 4, 2.4, 1.0, 0.8);
  }
  // ---- 建筑 C：仓库 ----
  { const cx = 0, cz = 23, w = 26, d = 12, h = 5.6, t = 0.5;
    wall('x', cz - d / 2, cx - w / 2, cx + w / 2, t, 0, h, 'concrete', [{ c: cx - 7, w: 2.4, type: 'door' }, { c: cx + 7, w: 2.4, type: 'door' }, { c: cx, w: 6, type: 'high' }]);
    wall('x', cz + d / 2, cx - w / 2, cx + w / 2, t, 0, h, 'concrete', [{ c: cx - 8, w: 6, type: 'high' }, { c: cx + 8, w: 6, type: 'high' }]);
    wall('z', cx - w / 2, cz - d / 2, cz + d / 2, t, 0, h, 'concrete', [{ c: cz, w: 4.4, type: 'gate' }]);
    wall('z', cx + w / 2, cz - d / 2, cz + d / 2, t, 0, h, 'concrete', [{ c: cz, w: 4.4, type: 'gate' }]);
    B('concDark', cx, h, cz, w + 0.6, 0.3, d + 0.6);
    B('cRed', cx - 7, 0, cz + 3, 6, 2.6, 2.4); B('cBlue', cx + 5, 0, cz - 2, 2.4, 2.6, 6);
    B('wood', cx, 0, cz + 2, 1.2, 1.2, 1.2); B('wood', cx + 1.4, 0, cz + 2, 1.2, 0.9, 1.2); B('wood', cx, 1.2, cz + 2, 1.2, 0.9, 1.2);
    B('metal', cx + 9, 0, cz + 3.5, 1.4, 1.4, 1.4);
  }
  // ---- 室外集装箱与箱子（可跳跃攀爬形成高地） ----
  B('cOrange', 10, 0, 7, 6, 2.6, 2.4); B('cGreen', 10, 2.6, 7, 6, 2.6, 2.4);
  B('wood', 6.4, 0, 9.5, 1.2, 0.9, 1.2); B('wood', 7.7, 0, 9.5, 1.2, 1.8, 1.2); B('wood', 7.0, 0, 10.8, 1.2, 0.9, 1.2);
  B('cBlue', -12, 0, -9, 2.4, 2.6, 6); B('cRed', -12, 0, -3, 2.4, 2.6, 6);
  B('wood', -9.6, 0, -9.2, 1.2, 0.9, 1.2); B('wood', -9.6, 0, -7.9, 1.2, 1.8, 1.2);
  B('cGreen', -30, 0, 12, 6, 2.6, 2.4); B('wood', -26, 0, 12, 1.2, 1.2, 1.2); B('wood', -26, 0, 14, 1.2, 0.9, 1.2);
  B('cRed', 32, 0, 8, 2.4, 2.6, 6); B('cOrange', 32, 0, 15, 2.4, 2.6, 6);
  B('wood', 28, 0, 6, 1.2, 1.2, 1.2); B('wood', 28, 0, 7.2, 1.2, 0.9, 1.2);
  // 路障与矮墙
  for (const [x, z, r] of [[-5, -3, 0], [5, 3.5, 0], [-3, 6, 1], [3, -6, 1], [-18, 2, 0], [16, -4, 0], [-8, 16, 1], [14, 12, 0]]) {
    if (r) B('concrete', x, 0, z, 0.8, 0.9, 3.4); else B('concrete', x, 0, z, 3.4, 0.9, 0.8);
  }
  B('metal', -35, 0, -2, 0.3, 1.6, 10); B('metal', 36, 0, -2, 0.3, 1.6, 10);  // 栏杆
  B('brick', -6, 0, -26, 8, 1.1, 0.5); B('brick', 8, 0, -30, 0.5, 1.1, 8);

  // ---- 路灯 ----
  const lampSpots = [[-14, 5], [14, -5], [5, -14], [-5, 14], [-30, 5], [30, 5], [5, 32], [-35, -30]];
  for (const [x, z] of lampSpots) {
    const pole = new THREE.CylinderGeometry(0.08, 0.1, 5.2, 8); pole.translate(x, 2.6, z);
    G('metal', pole, { minX: x - 0.12, maxX: x + 0.12, minY: 0, maxY: 5, minZ: z - 0.12, maxZ: z + 0.12 });
    const arm = new THREE.BoxGeometry(1.1, 0.08, 0.08); arm.translate(x + 0.5, 5.2, z); G('metal', arm);
    const bulb = new THREE.BoxGeometry(0.5, 0.12, 0.25); bulb.translate(x + 1.0, 5.1, z); G('lamp', bulb);
  }
  // ---- 树 ----
  const treeSpots = [[-34, -41], [-38, 20], [34, 41], [36, -34], [-20, 38], [-36, 34], [24, 36], [-8, -38], [40, 20], [-40, -12], [18, 4], [-20, 8]];
  for (const [x, z] of treeSpots) {
    const tr = new THREE.CylinderGeometry(0.22, 0.3, 3.4, 8); tr.translate(x, 1.7, z);
    G('trunk', tr, { minX: x - 0.3, maxX: x + 0.3, minY: 0, maxY: 3.4, minZ: z - 0.3, maxZ: z + 0.3 });
    const l1 = new THREE.SphereGeometry(1.9, 8, 6); l1.translate(x, 4.4, z); G('leaf', l1);
    const l2 = new THREE.SphereGeometry(1.3, 8, 6); l2.translate(x + 0.7, 5.6, z - 0.4); G('leaf', l2);
  }

  // ---- 合并网格 ----
  const staticMeshes = [];
  for (const key in groups) {
    const geo = mergeGeometries(groups[key], false);
    if (!geo) continue;
    const m = new THREE.Mesh(geo, MAT[key]);
    m.castShadow = key !== 'lamp'; m.receiveShadow = true;
    scene.add(m); meshes.push(m); staticMeshes.push(m);
    groups[key].forEach(g => g.dispose());
  }

  // ---- 远景建筑（无碰撞，仅装饰） ----
  const far = new THREE.Group();
  for (let i = 0; i < 22; i++) {
    const a = (i / 22) * Math.PI * 2, r = 85 + Math.random() * 25;
    const hh = 25 + Math.random() * 45, ww = 10 + Math.random() * 12;
    const m = new THREE.Mesh(new THREE.BoxGeometry(ww, hh, ww), MAT.far);
    m.position.set(Math.cos(a) * r, hh / 2, Math.sin(a) * r);
    far.add(m);
  }
  scene.add(far);

  const spawns = [[-38, -38], [38, -38], [-38, 38], [38, 38], [0, -38], [0, 38], [-38, 0], [38, 0]].map(([x, z]) => ({ x, z, yaw: Math.atan2(-x, -z) + Math.PI }));
  const openPoints = [[-6, -6], [6, -8], [8, 0], [-8, 4], [0, 10], [-20, 0], [18, 2], [-28, -4], [30, -6], [-4, 14], [12, -20], [-14, 8], [0, -16], [24, 26], [-26, 26]];

  return { colliders, meshes, spawns, openPoints, bounds: H, MAT };
}
