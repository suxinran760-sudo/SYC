import * as THREE from 'three';
import { App } from '@capacitor/app';
import { loadSettings, saveSettings, getLayout, DEFAULT_LAYOUT } from './settings.js';
import { Game } from './game.js';
import { WEAPONS, WEAPON_ORDER, SKINS, buildWeaponModel } from './weapons.js';
import { initAudio } from './audio.js';

const $ = (id) => document.getElementById(id);
const S = loadSettings();
const game = new Game($('game'), S);
const save = () => saveSettings(S);

// ================= 屏幕切换 =================
let current = 'menu', prev = 'menu';
function show(id) {
  prev = current; current = id;
  document.querySelectorAll('.screen').forEach(e => e.classList.add('hidden'));
  if (id) $(id).classList.remove('hidden');
  if (id === 'locker') openLocker(); else stopLocker();
  if (id === 'mode') refreshMode();
  if (id === 'settings') buildSettings();
}
document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => { initAudio(); show(b.dataset.go); }));

// ================= 模式选择 =================
function seg(id, opts, key, cb) {
  const el = $(id); el.innerHTML = '';
  opts.forEach(([label, val]) => {
    const b = document.createElement('button'); b.textContent = label;
    if (S[key] === val) b.classList.add('on');
    b.onclick = () => { S[key] = val; save(); [...el.children].forEach(c => c.classList.remove('on')); b.classList.add('on'); cb && cb(); };
    el.appendChild(b);
  });
}
function refreshMode() {
  seg('segMode', [['单人练习', 'practice'], ['击杀计分(5分钟)', 'kill']], 'mode');
  seg('segTargets', [['4', 4], ['6', 6], ['10', 10]], 'targets');
  seg('segDiff', [['慢', 0], ['中', 1], ['快', 2]], 'diff');
  seg('segTod', [['白天', 'day'], ['黄昏', 'dusk'], ['夜晚', 'night']], 'tod');
  $('modePrimary').textContent = WEAPONS[S.primary].name; $('modeSecondary').textContent = WEAPONS[S.secondary].name;
}
function startGame(cfg) {
  initAudio();
  show(null);
  $('hud').classList.remove('hidden', 'editing');
  applyLayout();
  game.applySettings();
  game.start(cfg || { mode: S.mode, targets: S.targets, diff: S.diff, tod: S.tod });
}
function leaveGame() {
  game.stop(); $('hud').classList.add('hidden'); resetInput(); show('menu');
}
$('btnStart').onclick = () => startGame();
$('btnTrain').onclick = () => startGame({ mode: 'practice', targets: 6, diff: 0, tod: S.tod });
$('btnExit').onclick = async () => { try { await App.exitApp(); } catch (e) { window.close(); } };
$('pResume').onclick = () => { show(null); game.setPaused(false); };
$('pSettings').onclick = () => { show('settings'); };
$('pQuit').onclick = leaveGame;
$('rAgain').onclick = () => startGame();
$('rMenu').onclick = leaveGame;
game.onEnd = (r) => {
  $('rKills').textContent = r.kills; $('rHeads').textContent = r.heads;
  $('rAcc').textContent = r.shots ? Math.round(r.hits / r.shots * 100) + '%' : '-';
  resetInput(); show('result');
};
function pauseGame() { if (game.running && !game.paused) { game.setPaused(true); resetInput(); show('pause'); } }

// ================= 设置界面 =================
const SCHEMA = [
  ['灵敏度', null],
  ['普通视角灵敏度', 'sensLook', 0.2, 3, 0.05],
  ['开镜灵敏度', 'sensAds', 0.1, 3, 0.05],
  ['狙击镜灵敏度（低倍）', 'sensScope', 0.05, 2, 0.05],
  ['狙击镜灵敏度（高倍）', 'sensScope2', 0.05, 2, 0.05],
  ['水平灵敏度', 'sensX', 0.3, 2.5, 0.05],
  ['垂直灵敏度', 'sensY', 0.3, 2.5, 0.05],
  ['陀螺仪', null],
  ['陀螺仪模式', 'gyro', [['关闭', 'off'], ['仅开镜', 'ads'], ['始终', 'always']]],
  ['陀螺仪灵敏度', 'gyroSens', 0.2, 4, 0.05],
  ['陀螺仪上下反转', 'gyroInvert', 'toggle'],
  ['画面与性能', null],
  ['画质', 'quality', [['低', 'low'], ['中', 'medium'], ['高', 'high'], ['极高', 'ultra']]],
  ['帧率上限', 'fps', [['30', 30], ['45', 45], ['60', 60]]],
  ['视野(FOV)', 'fov', 60, 100, 1],
  ['显示 FPS', 'showFps', 'toggle'],
  ['按钮', null],
  ['按钮大小', 'btnScale', 0.6, 1.6, 0.05],
  ['按钮透明度', 'btnOpacity', 0.2, 1, 0.05]
];
function buildSettings() {
  const box = $('settingsList'); box.innerHTML = '';
  for (const it of SCHEMA) {
    const [label, key, a, b, c] = it;
    if (key === null) { const h = document.createElement('div'); h.className = 'row'; h.innerHTML = `<b style="color:var(--acc2)">${label}</b>`; box.appendChild(h); continue; }
    const row = document.createElement('div'); row.className = 'row';
    const sp = document.createElement('span'); sp.textContent = label; row.appendChild(sp);
    if (Array.isArray(a)) {
      const sg = document.createElement('div'); sg.className = 'seg';
      a.forEach(([l, v]) => { const bt = document.createElement('button'); bt.textContent = l; if (S[key] === v) bt.classList.add('on'); bt.onclick = () => { S[key] = v; save(); game.applySettings(); [...sg.children].forEach(x => x.classList.remove('on')); bt.classList.add('on'); if (key === 'gyro') askMotion(); }; sg.appendChild(bt); });
      row.appendChild(sg);
    } else if (a === 'toggle') {
      const sg = document.createElement('div'); sg.className = 'seg';
      [['开', true], ['关', false]].forEach(([l, v]) => { const bt = document.createElement('button'); bt.textContent = l; if (!!S[key] === v) bt.classList.add('on'); bt.onclick = () => { S[key] = v; save(); game.applySettings(); [...sg.children].forEach(x => x.classList.remove('on')); bt.classList.add('on'); }; sg.appendChild(bt); });
      row.appendChild(sg);
    } else {
      const inp = document.createElement('input'); inp.type = 'range'; inp.min = a; inp.max = b; inp.step = c; inp.value = S[key];
      const val = document.createElement('span'); val.className = 'val'; val.textContent = (+S[key]).toFixed(c < 1 ? 2 : 0);
      inp.oninput = () => { S[key] = parseFloat(inp.value); val.textContent = S[key].toFixed(c < 1 ? 2 : 0); save(); game.applySettings(); if (current === 'settings' && $('hud').classList.contains('hidden') === false) applyLayout(); };
      row.appendChild(inp); row.appendChild(val);
    }
    box.appendChild(row);
  }
}
function askMotion() {
  try { if (window.DeviceMotionEvent && typeof DeviceMotionEvent.requestPermission === 'function') DeviceMotionEvent.requestPermission(); } catch (e) { /* ignore */ }
}
$('btnSettingsBack').onclick = () => { applyLayout(); game.applySettings(); show(prev === 'settings' ? 'menu' : prev); };

// ================= 触控输入 =================
const inp = game.inp;
const BTN_DEFS = [
  ['fire', '射击'], ['ads', '开镜'], ['jump', '跳'], ['crouch', '蹲'], ['reload', '换弹'], ['switch', '切枪'], ['grenade', '手雷'], ['zoom', '倍率'], ['pause', '‖']
];
const btnEls = {};
const btnsBox = $('btns');
for (const [id, label] of BTN_DEFS) {
  const el = document.createElement('div'); el.className = 'gbtn ' + id; el.textContent = label; el.id = id === 'zoom' ? 'zoomBtn' : 'btn_' + id; el.dataset.id = id;
  btnsBox.appendChild(el); btnEls[id] = el;
}
let layoutMode = false, editLayout = null, selBtn = null;
function applyLayout(lay) {
  const L = lay || getLayout(S);
  for (const id in btnEls) {
    const d = L[id], el = btnEls[id];
    el.style.left = d.x + '%'; el.style.top = d.y + '%';
    const sz = Math.round(d.s * S.btnScale); el.style.width = el.style.height = sz + 'px';
    el.style.opacity = S.btnOpacity; el.style.fontSize = Math.max(10, sz * 0.22) + 'px';
  }
}
applyLayout();

function resetInput() {
  inp.fire = false; inp.mx = inp.my = 0; inp.lookX = inp.lookY = 0;
  joyId = null; lookId = null; $('joyBase').style.display = 'none';
  for (const id in btnEls) btnEls[id].classList.remove('down');
}

// 摇杆 + 视角
const layer = $('touchLayer');
let joyId = null, joyO = { x: 0, y: 0 }, lookId = null, lookLast = { x: 0, y: 0 };
const JR = 55;
layer.addEventListener('pointerdown', (e) => {
  if (!game.running || game.paused || layoutMode) return;
  initAudio();
  if (e.clientX < innerWidth * 0.42 && joyId === null) {
    joyId = e.pointerId; joyO = { x: e.clientX, y: e.clientY };
    const jb = $('joyBase'); jb.style.display = 'block'; jb.style.left = e.clientX + 'px'; jb.style.top = e.clientY + 'px';
    $('joyStick').style.transform = 'translate(0,0)';
  } else if (lookId === null) { lookId = e.pointerId; lookLast = { x: e.clientX, y: e.clientY }; }
  layer.setPointerCapture(e.pointerId);
});
layer.addEventListener('pointermove', (e) => {
  if (e.pointerId === joyId) {
    let dx = e.clientX - joyO.x, dy = e.clientY - joyO.y; const d = Math.hypot(dx, dy);
    if (d > JR) { dx = dx / d * JR; dy = dy / d * JR; }
    inp.mx = dx / JR; inp.my = -dy / JR;
    $('joyStick').style.transform = `translate(${dx}px,${dy}px)`;
  } else if (e.pointerId === lookId) {
    inp.lookX += e.clientX - lookLast.x; inp.lookY += e.clientY - lookLast.y; lookLast = { x: e.clientX, y: e.clientY };
  }
});
const upHandler = (e) => {
  if (e.pointerId === joyId) { joyId = null; inp.mx = inp.my = 0; $('joyBase').style.display = 'none'; }
  if (e.pointerId === lookId) lookId = null;
};
layer.addEventListener('pointerup', upHandler); layer.addEventListener('pointercancel', upHandler);

// 按钮
const fireState = { id: null, last: { x: 0, y: 0 } };
function press(id, down, el) {
  if (down) el.classList.add('down'); else el.classList.remove('down');
  switch (id) {
    case 'fire': inp.fire = down; break;
    case 'ads': if (down) inp.adsTap = true; break;
    case 'jump': if (down) inp.jump = true; break;
    case 'crouch': if (down) inp.crouchTap = true; break;
    case 'reload': if (down) inp.reload = true; break;
    case 'switch': if (down) inp.sw = true; break;
    case 'grenade': if (down) inp.grenade = true; break;
    case 'zoom': if (down) inp.zoomTap = true; break;
    case 'pause': if (down) pauseGame(); break;
  }
}
for (const id in btnEls) {
  const el = btnEls[id];
  let dragging = false, dragId = null;
  el.addEventListener('pointerdown', (e) => {
    e.stopPropagation();
    if (layoutMode) { dragging = true; dragId = e.pointerId; el.setPointerCapture(e.pointerId); selectBtn(id); return; }
    if (!game.running || (game.paused && id !== 'pause')) return;
    initAudio();
    el.setPointerCapture(e.pointerId); dragId = e.pointerId;
    if (id === 'fire') fireState.last = { x: e.clientX, y: e.clientY };
    press(id, true, el);
  });
  el.addEventListener('pointermove', (e) => {
    if (layoutMode) {
      if (!dragging || e.pointerId !== dragId) return;
      const x = Math.min(98, Math.max(2, e.clientX / innerWidth * 100)), y = Math.min(96, Math.max(4, e.clientY / innerHeight * 100));
      editLayout[id].x = +x.toFixed(1); editLayout[id].y = +y.toFixed(1); applyLayout(editLayout); return;
    }
    if (id === 'fire' && inp.fire && e.pointerId === dragId) {
      inp.lookX += e.clientX - fireState.last.x; inp.lookY += e.clientY - fireState.last.y; fireState.last = { x: e.clientX, y: e.clientY };
    }
  });
  const up = (e) => { if (layoutMode) { dragging = false; return; } if (e.pointerId === dragId) { dragId = null; press(id, false, el); } };
  el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
}

// ================= 按钮布局编辑 =================
function selectBtn(id) {
  selBtn = id;
  for (const k in btnEls) btnEls[k].classList.toggle('sel', k === id);
  $('lpSize').value = editLayout[id].s; $('lpSizeV').textContent = editLayout[id].s;
}
function loadSlot(slot) {
  S.layoutSlot = slot;
  editLayout = getLayout(S); applyLayout(editLayout); selectBtn(selBtn || 'fire');
  [...$('slotSeg').children].forEach(c => c.classList.toggle('on', c.dataset.s === slot));
}
function openLayoutEditor() {
  game.stop(); layoutMode = true; selBtn = null;
  show(null);
  $('hud').classList.remove('hidden'); $('hud').classList.add('editing'); $('layoutPanel').classList.remove('hidden');
  const sg = $('slotSeg'); sg.innerHTML = '';
  ['A', 'B', 'C'].forEach(s => { const b = document.createElement('button'); b.textContent = '方案' + s; b.dataset.s = s; b.onclick = () => loadSlot(s); sg.appendChild(b); });
  $('lpOpacity').value = S.btnOpacity;
  for (const k in btnEls) btnEls[k].style.display = '';
  loadSlot(S.layoutSlot);
}
$('btnLayout').onclick = openLayoutEditor;
$('lpSize').oninput = (e) => { if (!selBtn) return; editLayout[selBtn].s = +e.target.value; $('lpSizeV').textContent = e.target.value; applyLayout(editLayout); };
$('lpOpacity').oninput = (e) => { S.btnOpacity = +e.target.value; applyLayout(editLayout); };
$('lpReset').onclick = () => { editLayout = JSON.parse(JSON.stringify(DEFAULT_LAYOUT)); applyLayout(editLayout); selectBtn(selBtn || 'fire'); };
$('lpSave').onclick = () => {
  S.layouts[S.layoutSlot] = JSON.parse(JSON.stringify(editLayout)); save();
  layoutMode = false; $('layoutPanel').classList.add('hidden'); $('hud').classList.add('hidden'); $('hud').classList.remove('editing');
  for (const k in btnEls) btnEls[k].classList.remove('sel');
  current = 'menu'; prev = 'menu';
  show('settings');
};

// ================= 武器仓库（3D 预览） =================
let lk = null;
function openLocker() {
  const cv = $('lkCanvas');
  if (!lk) {
    const r = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true });
    const sc = new THREE.Scene(); const cam = new THREE.PerspectiveCamera(35, 1.6, 0.05, 20); cam.position.set(0, 0.15, 1.5); cam.lookAt(0, 0, 0);
    sc.add(new THREE.HemisphereLight(0xcfe3ff, 0x333344, 1.4));
    const dl = new THREE.DirectionalLight(0xffffff, 2.2); dl.position.set(2, 3, 2); sc.add(dl);
    const dl2 = new THREE.DirectionalLight(0xffb070, 1.0); dl2.position.set(-2, 1, -2); sc.add(dl2);
    lk = { r, sc, cam, model: null, sel: S.primary, rotY: Math.PI / 2 + 0.4, drag: false, lastX: 0, raf: 0, hold: new THREE.Group() };
    sc.add(lk.hold);
    cv.addEventListener('pointerdown', e => { lk.drag = true; lk.lastX = e.clientX; cv.setPointerCapture(e.pointerId); });
    cv.addEventListener('pointermove', e => { if (lk.drag) { lk.rotY += (e.clientX - lk.lastX) * 0.012; lk.lastX = e.clientX; } });
    cv.addEventListener('pointerup', () => lk.drag = false); cv.addEventListener('pointercancel', () => lk.drag = false);
  }
  const w = cv.clientWidth || 400, h = cv.clientHeight || 250;
  lk.r.setPixelRatio(Math.min(devicePixelRatio, 2)); lk.r.setSize(w, h, false); lk.cam.aspect = w / h; lk.cam.updateProjectionMatrix();
  buildLockerList(); selectLocker(lk.sel);
  const tick = () => { lk.raf = requestAnimationFrame(tick); if (!lk.drag) lk.rotY += 0.006; lk.hold.rotation.y = lk.rotY; lk.r.render(lk.sc, lk.cam); };
  cancelAnimationFrame(lk.raf); tick();
}
function stopLocker() { if (lk) cancelAnimationFrame(lk.raf); }
function buildLockerList() {
  const box = $('lockerList'); box.innerHTML = '';
  WEAPON_ORDER.forEach(id => {
    const b = document.createElement('button'); b.dataset.id = id; b.innerHTML = `${WEAPONS[id].name}<small>${WEAPONS[id].cn}</small>`;
    b.onclick = () => selectLocker(id); box.appendChild(b);
  });
}
function selectLocker(id) {
  lk.sel = id; const w = WEAPONS[id];
  [...$('lockerList').children].forEach(c => c.classList.toggle('on', c.dataset.id === id));
  $('lkName').textContent = w.name; $('lkType').textContent = w.cn;
  const skin = S.skins[id] || 0;
  lk.hold.clear();
  const m = buildWeaponModel(id, skin, false);
  const box = new THREE.Box3().setFromObject(m); const c = box.getCenter(new THREE.Vector3()); const size = box.getSize(new THREE.Vector3());
  m.position.sub(c); const s = 0.9 / Math.max(size.x, size.z, 0.01); m.scale.setScalar(s); m.position.multiplyScalar(s);
  lk.hold.add(m);
  const sk = $('lkSkins'); sk.innerHTML = '';
  SKINS.forEach((k, i) => {
    const b = document.createElement('button'); b.textContent = k.name; b.style.background = '#' + k.color.toString(16).padStart(6, '0'); if (i === skin) b.classList.add('on');
    b.onclick = () => { S.skins[id] = i; save(); selectLocker(id); }; sk.appendChild(b);
  });
  const stat = (label, txt, pct) => `<div class="stat"><div class="l"><span>${label}</span><b>${txt}</b></div><div class="bar"><i style="width:${Math.max(3, Math.min(100, pct))}%"></i></div></div>`;
  const dmgTotal = w.dmg * (w.pellets > 1 ? w.pellets * 0.6 : 1);
  $('lkStats').innerHTML =
    stat('伤害', w.dmg + (w.pellets > 1 ? ' ×' + w.pellets : ''), dmgTotal / 1.5) +
    stat('射速', w.rpm + ' 发/分', w.rpm / 8) +
    stat('弹匣 / 备弹', w.mag + ' / ' + w.reserve, w.mag * 2.5) +
    stat('换弹', w.reload + ' 秒', 100 - w.reload * 18) +
    stat('射程', w.range + ' 米', w.range / 6) +
    stat('稳定性', '', 100 - w.recoil * 1600) +
    stat('爆头倍率', '×' + w.headMul, w.headMul * 30);
  $('lkPri').textContent = WEAPONS[S.primary].name; $('lkSec').textContent = WEAPONS[S.secondary].name;
}
$('lkSetPri').onclick = () => { if (S.secondary === lk.sel) S.secondary = S.primary; S.primary = lk.sel; save(); selectLocker(lk.sel); };
$('lkSetSec').onclick = () => { if (S.primary === lk.sel) S.primary = S.secondary; S.secondary = lk.sel; save(); selectLocker(lk.sel); };

// ================= 系统事件 =================
document.addEventListener('visibilitychange', () => { if (document.hidden) pauseGame(); });
try {
  App.addListener('backButton', () => {
    if (layoutMode) return;
    if (game.running && !game.paused) pauseGame();
    else if (current === 'pause') { show(null); game.setPaused(false); }
    else if (current !== 'menu') show(current === 'settings' && prev === 'pause' ? 'pause' : 'menu');
  });
} catch (e) { /* 浏览器环境 */ }
document.addEventListener('contextmenu', e => e.preventDefault());
show('menu');
